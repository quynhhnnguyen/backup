﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CoinMachine
{
    /* This application is used for calculating Amount of Coins 
     * which user is received after inputing Amount of money
     * Author: Quynh Nguyen (Queenie)
     * Date: Dec - 04 - 2018 
     */

    public partial class frmMain : Form
    {
        const decimal TOONIE = 2;
        const decimal LOONIE = 1;
        const decimal QUARTER = 0.25m;
        const decimal PENNY = 0.01m;
        const decimal DIME = 0.1m;
        const decimal NICKLES = 0.05m;


        public frmMain()
        {
            InitializeComponent();
        }

        private void btnExchange_Click(object sender, EventArgs e)
        {
            decimal amount = Convert.ToDecimal(txtAmountMoney.Text);
            decimal remaindedAmount = 0;
  
            //Two Dollars
            txtToonie.Text = (amount / TOONIE).ToString();
            remaindedAmount = amount % TOONIE;

            //One Dollar
            txtLoonie.Text = (remaindedAmount / LOONIE).ToString();
            remaindedAmount %= LOONIE;


            // 25 Cents
            txtQuarters.Text = (remaindedAmount / QUARTER).ToString();
            remaindedAmount %= QUARTER;

            // 10 Cents
            txtDims.Text = (remaindedAmount / DIME).ToString();
            remaindedAmount %= DIME;

            // 5 Cents
            txtNickles.Text = (remaindedAmount / NICKLES).ToString();
            remaindedAmount %= NICKLES;

            // 1 Cent
            txtPennies.Text = (remaindedAmount / PENNY).ToString();

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtAmountMoney.Text = "";
            txtAmountMoney.Focus();
            txtToonie.Text = "";
            txtLoonie.Text = "";
            txtQuarters.Text = "";
            txtDims.Text = "";
            txtNickles.Text = "";
            txtPennies.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
