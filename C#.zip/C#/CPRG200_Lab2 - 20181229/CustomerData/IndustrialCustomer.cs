﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerData
{
    [Serializable]
    public class IndustrialCustomer : Customer
    {
        // construction
        public IndustrialCustomer() : base(-1, "", 'I', 0)
        {

        }

        // construction
        public IndustrialCustomer(Int32 accountNo = -1, string customerName = "",
                        char customerType = 'I', decimal chargeAmount = 0) :
            base(accountNo, customerName, customerType, chargeAmount)
        {
            //no need to implement
        }

        // Overload method
        public override decimal CalculateCharge(decimal kwhPowerUsed, decimal kwhOffPeakUsed = 0)
        {
            if(kwhPowerUsed < 0 || kwhOffPeakUsed < 0)
            {
                return this.ChargeAmount;
            }

            this.ChargeAmount = 76; // default price even though kWhPeekHourUsed is zero

            // calculate charge for peak hour power used
            if (kwhPowerUsed > 1000)
            {
                this.ChargeAmount += (kwhPowerUsed - 1000m) * 0.065m;
            }

            // calculate charge for off-peak hour power used
            this.ChargeAmount += 40; // default price even though kWhOffPeakHourUsed is zero

            // different unit price is applied when power used is over 1000
            if (kwhOffPeakUsed > 1000)
            {
                this.ChargeAmount += (kwhOffPeakUsed - 1000m) * 0.028m;
            }

            return this.ChargeAmount;
        }

        public override List<string> ToArrayOfValues()
        {
            List<string> result = new List<string>();
            result.Add(this.AccountNo.ToString());
            result.Add(this.CustomerName);
            result.Add("Industrial");
            result.Add(this.ChargeAmount.ToString());
            return result;
        }
    }
}
