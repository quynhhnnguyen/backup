﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Exercise_D3
{
    public class FileIO
    {
        const string path = "numbers.txt";

        //when working with array, don't need to use key "ref" or "out". Otherwise, it will change location of array.
        // reads data from the file and puts in an array and returns number of elements
        public static int ReadData(double[] data)
        {
            int count = 0; //counts numbers as it reads
            FileStream fs = null;
            StreamReader sr = null;
            string line; // for reading.
            double num; // for reading.

            //open the file for reading and read number into data.
            try
            {
                fs = new FileStream(path, FileMode.Open, FileAccess.Read);
                sr = new StreamReader(fs);
                while (!sr.EndOfStream)
                {
                    line = sr.ReadLine(); //read the net line
                    num = Convert.ToDouble(line);
                    data[count] = num;
                    count++;
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("File contains non-numeric data. Aborting reading");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while reading the file: " + ex.Message, ex.GetType().ToString());
            }
            finally
            {
                //close the file if open
                if(sr != null)
                {
                    sr.Close(); // file stream should be closed too.
                }
            }

            return count; // data.Length;
        }

        // writes data from array to file
        public static void WriteData(double[] data,  int count)
        {
            FileStream fs = null;
            StreamWriter sw = null;

            try
            {
                //open the file for writing  and overwrite old content.
                fs = new FileStream(path, FileMode.Create, FileAccess.Write);
                sw = new StreamWriter(fs);

                // Write data
                for(int i=0; i<count; i++)
                {
                    sw.WriteLine(data[i].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while writing to the file: " +
                    ex.Message, ex.GetType().ToString());

            }
            finally
            {
                if (sw != null) sw.Close(); // also close fs
            }
        }
    }
}
