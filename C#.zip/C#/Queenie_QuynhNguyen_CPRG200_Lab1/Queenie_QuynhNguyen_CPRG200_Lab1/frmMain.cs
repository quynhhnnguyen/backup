﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Queenie_QuynhNguyen_CPRG200_Lab1
{
    /* This is application which allows Customer calculates the Power Charge Bill based on Customer Type
       Author: Quynh Nguyen (Queenie)
       Date: Dec - 05 - 2018
     */
    public partial class frmMain : Form
    {
        // class-level declarations
        // CONSTANT VARIABLES
        const decimal TAX_PCT = 0.05m; // tax percent
        private const string POWER_USED_LABEL = "Power Used (kWh):";
        private const string PEAK_HOUR_POWER_USED_LABEL = "Peak Hour Used (kWh):";
        private const string EMPTY_VALUE = "";
        private const string DOLLAR_FORMAT = "c";

        enum CustomerTypeEnum {Residential, Commercial, Industrial}; // Customer Types

        public frmMain()
        {
            InitializeComponent();
        }

        // Calculate the Power Charge Bill based on Customer Type
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal result = 0.0m; //output value

            int customerType = cbbCustomerType.SelectedIndex; // selected customer type

            try
            {
                // validate the input value
                if (Validator.IsProvided(txtPowerUsed, txtPowerUsed.Name) &&
                    Validator.IsNonNegativeNumber(txtPowerUsed, txtPowerUsed.Name))
                {

                    decimal kWhUsed = Convert.ToDecimal(txtPowerUsed.Text); // kWh power used or  kWh peak hour used

                    // calculate charged bill based on Customer Type
                    switch (customerType)
                    {
                        case (int)CustomerTypeEnum.Residential:
                            result = CalculateBillForResidential(kWhUsed);
                            break;
                        case (int)CustomerTypeEnum.Commercial:
                            result = CalculateBillForCommercial(kWhUsed);
                            break;
                        case (int)CustomerTypeEnum.Industrial:
                            // validate the input value
                            if (Validator.IsProvided(txtOffPeakHours, txtOffPeakHours.Name) &&
                                     Validator.IsNonNegativeNumber(txtOffPeakHours, txtOffPeakHours.Name))
                            {
                                // kWh off-peak hour used
                                decimal kWhOffPeakHours = Convert.ToDecimal(txtOffPeakHours.Text);
                                result = CalculateBillForIndustrial(kWhUsed, kWhOffPeakHours);                                
                            }

                            break;

                    }

                    DrawBillInformation(result, kWhUsed);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" +
                                ex.GetType().ToString() + "\n", "Exception");
            }
           
        }

        private void DrawBillInformation(decimal result, decimal kWhUsed)
        {
            //set information for Bill
            if(cbbCustomerType.SelectedIndex == (int)CustomerTypeEnum.Industrial)
                txtOffPeakInfo.Text = txtOffPeakHours.Text;

            //set information for Bill
            txtEstimatedCharge.Text = result.ToString(DOLLAR_FORMAT);
            txtPowerUsedInfo.Text = kWhUsed.ToString();
            grpBInfo.Show();
        }

        // calculate bill for Industrial Customer
        private static decimal CalculateBillForIndustrial(decimal kWhPeekHourUsed, decimal kWhOffPeakHourUsed)
        {
            decimal result = 76; // default price even though kWhPeekHourUsed is zero

            // calculate charge for peak hour power used
            if (kWhPeekHourUsed > 1000)
            {
                result += (kWhPeekHourUsed - 1000m) * 0.065m;
            }

            // calculate charge for off-peak hour power used
            if (kWhOffPeakHourUsed >= 0)
            {
                result += 40; // default price even though kWhOffPeakHourUsed is zero

                // different unit price is applied when power used is over 1000
                if (kWhOffPeakHourUsed > 1000) 
                {
                    result += (kWhOffPeakHourUsed - 1000m) * 0.028m;
                }
            }

            return result;
        }

        // calculate bill for Commercial Customer
        private static decimal CalculateBillForCommercial(decimal kWhUsed)
        {
            decimal result = 60; // default value, even though power used is zero

            // different unit price is applied when power used is over 1000
            if (kWhUsed > 1000) 
            {
                result += (kWhUsed - 1000m) * 0.045m;
            }

            return result;
        }

        // calculate bill for Residential Customer
        private static decimal CalculateBillForResidential(decimal kWhUsed)
        {
            // 6.00 - default price, 0.052 - unit price
            return 6.00m + 0.052m * kWhUsed;
        }

        // Reset all information on Form
        private void btnReset_Click(object sender, EventArgs e)
        {
            lblPowerUsed.Text = POWER_USED_LABEL;
            lblPowerUsedInfo.Text = POWER_USED_LABEL;
            txtPowerUsed.Text = EMPTY_VALUE;
            txtPowerUsed.Focus();
            txtEstimatedCharge.Text = EMPTY_VALUE;
            cbbCustomerType.SelectedIndex = (int)CustomerTypeEnum.Residential;
            grpBoxPeakHour.Visible = false;
            grpBInfo.Hide();
        }

        // Exit button is hit, close the form and exit the application
        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // display peak/ off-peak hours input based on Customer Type
        private void cbbCustomerType_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtEstimatedCharge.Text = EMPTY_VALUE;
            txtPowerUsed.Text = EMPTY_VALUE;

            // peak hour power used & off-peak hour power used are displayed for Industrial Customer Only.
            if ((int)CustomerTypeEnum.Industrial == cbbCustomerType.SelectedIndex)
            {
                //input information Section
                grpBoxPeakHour.Visible = true;
                lblPowerUsed.Text = PEAK_HOUR_POWER_USED_LABEL;
                lblPowerUsedInfo.Text = PEAK_HOUR_POWER_USED_LABEL;

                //Bill information Section
                lblOffPeakInfo.Show();
                txtOffPeakInfo.Show();

            } else
            {
                //input information Section
                grpBoxPeakHour.Visible = false;
                lblPowerUsed.Text = POWER_USED_LABEL;
                lblPowerUsedInfo.Text = POWER_USED_LABEL;
                txtOffPeakHours.Text = EMPTY_VALUE;

                //Bill information Section
                lblOffPeakInfo.Hide();
                txtOffPeakInfo.Hide();
            }

            //Bill information Section
            grpBInfo.Hide();
        }

        // set default value for all components when Form is loaded
        private void frmMain_Load(object sender, EventArgs e)
        {
            txtPowerUsed.Focus();
            cbbCustomerType.SelectedIndex = (int)CustomerTypeEnum.Residential;
            grpBoxPeakHour.Hide();
            grpBInfo.Hide();
        }

    }
}
