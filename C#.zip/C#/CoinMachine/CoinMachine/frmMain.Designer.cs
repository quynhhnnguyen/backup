﻿namespace CoinMachine
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCaption = new System.Windows.Forms.Label();
            this.lblAmountMoney = new System.Windows.Forms.Label();
            this.txtAmountMoney = new System.Windows.Forms.TextBox();
            this.lblExample = new System.Windows.Forms.Label();
            this.btnExchange = new System.Windows.Forms.Button();
            this.lblToonie = new System.Windows.Forms.Label();
            this.lblLoonie = new System.Windows.Forms.Label();
            this.lblQuarter = new System.Windows.Forms.Label();
            this.lblDim = new System.Windows.Forms.Label();
            this.lblNickels = new System.Windows.Forms.Label();
            this.lblPenny = new System.Windows.Forms.Label();
            this.txtToonie = new System.Windows.Forms.TextBox();
            this.txtLoonie = new System.Windows.Forms.TextBox();
            this.txtQuarters = new System.Windows.Forms.TextBox();
            this.txtDims = new System.Windows.Forms.TextBox();
            this.txtNickles = new System.Windows.Forms.TextBox();
            this.txtPennies = new System.Windows.Forms.TextBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblCaption
            // 
            this.lblCaption.AutoSize = true;
            this.lblCaption.Font = new System.Drawing.Font("Monotype Corsiva", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCaption.Location = new System.Drawing.Point(257, 25);
            this.lblCaption.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCaption.Name = "lblCaption";
            this.lblCaption.Size = new System.Drawing.Size(273, 57);
            this.lblCaption.TabIndex = 0;
            this.lblCaption.Text = "Coin Machine";
            // 
            // lblAmountMoney
            // 
            this.lblAmountMoney.AutoSize = true;
            this.lblAmountMoney.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAmountMoney.Location = new System.Drawing.Point(97, 106);
            this.lblAmountMoney.Name = "lblAmountMoney";
            this.lblAmountMoney.Size = new System.Drawing.Size(154, 20);
            this.lblAmountMoney.TabIndex = 1;
            this.lblAmountMoney.Text = "Amount of Money:";
            // 
            // txtAmountMoney
            // 
            this.txtAmountMoney.Location = new System.Drawing.Point(258, 103);
            this.txtAmountMoney.Name = "txtAmountMoney";
            this.txtAmountMoney.Size = new System.Drawing.Size(169, 26);
            this.txtAmountMoney.TabIndex = 2;
            // 
            // lblExample
            // 
            this.lblExample.AutoSize = true;
            this.lblExample.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExample.Location = new System.Drawing.Point(254, 132);
            this.lblExample.Name = "lblExample";
            this.lblExample.Size = new System.Drawing.Size(238, 18);
            this.lblExample.TabIndex = 3;
            this.lblExample.Text = "(C$ 9.99 means 9 dollars 99 cents)";
            // 
            // btnExchange
            // 
            this.btnExchange.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExchange.Location = new System.Drawing.Point(448, 103);
            this.btnExchange.Name = "btnExchange";
            this.btnExchange.Size = new System.Drawing.Size(113, 26);
            this.btnExchange.TabIndex = 4;
            this.btnExchange.Text = "&Exchange";
            this.btnExchange.UseVisualStyleBackColor = true;
            this.btnExchange.Click += new System.EventHandler(this.btnExchange_Click);
            // 
            // lblToonie
            // 
            this.lblToonie.AutoSize = true;
            this.lblToonie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblToonie.Location = new System.Drawing.Point(181, 174);
            this.lblToonie.Name = "lblToonie";
            this.lblToonie.Size = new System.Drawing.Size(68, 20);
            this.lblToonie.TabIndex = 5;
            this.lblToonie.Text = "Toonie:";
            // 
            // lblLoonie
            // 
            this.lblLoonie.AutoSize = true;
            this.lblLoonie.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoonie.Location = new System.Drawing.Point(181, 208);
            this.lblLoonie.Name = "lblLoonie";
            this.lblLoonie.Size = new System.Drawing.Size(68, 20);
            this.lblLoonie.TabIndex = 6;
            this.lblLoonie.Text = "Loonie:";
            // 
            // lblQuarter
            // 
            this.lblQuarter.AutoSize = true;
            this.lblQuarter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuarter.Location = new System.Drawing.Point(164, 240);
            this.lblQuarter.Name = "lblQuarter";
            this.lblQuarter.Size = new System.Drawing.Size(84, 20);
            this.lblQuarter.TabIndex = 7;
            this.lblQuarter.Text = "Quarters:";
            // 
            // lblDim
            // 
            this.lblDim.AutoSize = true;
            this.lblDim.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDim.Location = new System.Drawing.Point(194, 272);
            this.lblDim.Name = "lblDim";
            this.lblDim.Size = new System.Drawing.Size(54, 20);
            this.lblDim.TabIndex = 8;
            this.lblDim.Text = "Dims:";
            // 
            // lblNickels
            // 
            this.lblNickels.AutoSize = true;
            this.lblNickels.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNickels.Location = new System.Drawing.Point(177, 305);
            this.lblNickels.Name = "lblNickels";
            this.lblNickels.Size = new System.Drawing.Size(71, 20);
            this.lblNickels.TabIndex = 9;
            this.lblNickels.Text = "Nickles:";
            // 
            // lblPenny
            // 
            this.lblPenny.AutoSize = true;
            this.lblPenny.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPenny.Location = new System.Drawing.Point(168, 335);
            this.lblPenny.Name = "lblPenny";
            this.lblPenny.Size = new System.Drawing.Size(78, 20);
            this.lblPenny.TabIndex = 10;
            this.lblPenny.Text = "Pennies:";
            // 
            // txtToonie
            // 
            this.txtToonie.Enabled = false;
            this.txtToonie.Location = new System.Drawing.Point(258, 168);
            this.txtToonie.Name = "txtToonie";
            this.txtToonie.Size = new System.Drawing.Size(169, 26);
            this.txtToonie.TabIndex = 11;
            // 
            // txtLoonie
            // 
            this.txtLoonie.Enabled = false;
            this.txtLoonie.Location = new System.Drawing.Point(257, 203);
            this.txtLoonie.Name = "txtLoonie";
            this.txtLoonie.Size = new System.Drawing.Size(169, 26);
            this.txtLoonie.TabIndex = 12;
            // 
            // txtQuarters
            // 
            this.txtQuarters.Enabled = false;
            this.txtQuarters.Location = new System.Drawing.Point(257, 235);
            this.txtQuarters.Name = "txtQuarters";
            this.txtQuarters.Size = new System.Drawing.Size(169, 26);
            this.txtQuarters.TabIndex = 13;
            // 
            // txtDims
            // 
            this.txtDims.Enabled = false;
            this.txtDims.Location = new System.Drawing.Point(257, 267);
            this.txtDims.Name = "txtDims";
            this.txtDims.Size = new System.Drawing.Size(169, 26);
            this.txtDims.TabIndex = 14;
            // 
            // txtNickles
            // 
            this.txtNickles.Enabled = false;
            this.txtNickles.Location = new System.Drawing.Point(257, 299);
            this.txtNickles.Name = "txtNickles";
            this.txtNickles.Size = new System.Drawing.Size(169, 26);
            this.txtNickles.TabIndex = 15;
            // 
            // txtPennies
            // 
            this.txtPennies.Enabled = false;
            this.txtPennies.Location = new System.Drawing.Point(257, 331);
            this.txtPennies.Name = "txtPennies";
            this.txtPennies.Size = new System.Drawing.Size(169, 26);
            this.txtPennies.TabIndex = 16;
            // 
            // btnReset
            // 
            this.btnReset.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.Location = new System.Drawing.Point(567, 103);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(65, 26);
            this.btnReset.TabIndex = 17;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(640, 103);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(55, 26);
            this.btnExit.TabIndex = 18;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(859, 402);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.txtPennies);
            this.Controls.Add(this.txtNickles);
            this.Controls.Add(this.txtDims);
            this.Controls.Add(this.txtQuarters);
            this.Controls.Add(this.txtLoonie);
            this.Controls.Add(this.txtToonie);
            this.Controls.Add(this.lblPenny);
            this.Controls.Add(this.lblNickels);
            this.Controls.Add(this.lblDim);
            this.Controls.Add(this.lblQuarter);
            this.Controls.Add(this.lblLoonie);
            this.Controls.Add(this.lblToonie);
            this.Controls.Add(this.btnExchange);
            this.Controls.Add(this.lblExample);
            this.Controls.Add(this.txtAmountMoney);
            this.Controls.Add(this.lblAmountMoney);
            this.Controls.Add(this.lblCaption);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmMain";
            this.Text = "Coin Machine";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCaption;
        private System.Windows.Forms.Label lblAmountMoney;
        private System.Windows.Forms.TextBox txtAmountMoney;
        private System.Windows.Forms.Label lblExample;
        private System.Windows.Forms.Button btnExchange;
        private System.Windows.Forms.Label lblToonie;
        private System.Windows.Forms.Label lblLoonie;
        private System.Windows.Forms.Label lblQuarter;
        private System.Windows.Forms.Label lblDim;
        private System.Windows.Forms.Label lblNickels;
        private System.Windows.Forms.Label lblPenny;
        private System.Windows.Forms.TextBox txtToonie;
        private System.Windows.Forms.TextBox txtLoonie;
        private System.Windows.Forms.TextBox txtQuarters;
        private System.Windows.Forms.TextBox txtDims;
        private System.Windows.Forms.TextBox txtNickles;
        private System.Windows.Forms.TextBox txtPennies;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
    }
}

