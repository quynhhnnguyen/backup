﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            customerIDComboBox.DataSource = DBUtilities.GetCustomerIds();
        }

        private void customerIDComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string customerId = customerIDComboBox.SelectedValue.ToString();
            DisplayCustomer(customerId);
            orderDataGridView.DataSource = DBUtilities.GetOrdersByCustomerId(customerId);
        }
        
        private void DisplayCustomer(string custID)
        {
            Customer cust = DBUtilities.GetCustomer(custID);
            addressTextBox.Text = cust.Address;
            cityTextBox.Text = cust.City;
            companyNameTextBox.Text = cust.CompanyName;
            contactNameTextBox.Text = cust.ContactName;
            contactTitleTextBox.Text = cust.ContactTitle;
            countryTextBox.Text = cust.Country;
            faxTextBox.Text = cust.Fax;
            phoneTextBox.Text = cust.Phone;
            postalCodeTextBox.Text = cust.PostalCode;
            regionTextBox.Text = cust.Region;
        }
    }
}
