﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerData
{
    [Serializable]
    public class CommercialCustomer : Customer
    {
        // construction
        public CommercialCustomer() : base(-1, "", 'C', 0)
        {

        }

        // construction
        public CommercialCustomer(Int32 accountNo = -1, string customerName = "",
                        char customerType = 'C', decimal chargeAmount = 0) :
            base(accountNo, customerName, customerType, chargeAmount)
        {
            //no need to implement
        }

        public override decimal CalculateCharge(decimal kwhPowerUsed, decimal kwhOffPeakPowerUsed = 0)
        {
            if (kwhPowerUsed >= 0)
            {
                this.ChargeAmount = 60; // default value, even though power used is zero

                // different unit price is applied when power used is over 1000
                if (kwhPowerUsed > 1000)
                {
                    this.ChargeAmount += (kwhPowerUsed - 1000m) * 0.045m;
                }
            }

            return this.ChargeAmount;
        }

        public override List<string> ToArrayOfValues()
        {
            List<string> result = new List<string>();
            result.Add(this.AccountNo.ToString());
            result.Add(this.CustomerName);
            result.Add("Commercial");
            result.Add(this.ChargeAmount.ToString());
            return result;
        }
    }
}
