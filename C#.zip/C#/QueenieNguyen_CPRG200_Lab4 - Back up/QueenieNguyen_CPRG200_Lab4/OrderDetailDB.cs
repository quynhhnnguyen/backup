﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueenieNguyen_CPRG200_Lab4
{
    /* Business class for Order Detail
     * Author: Queenie Nguyen
     * Created Date: Jan - 11 - 2019
     */
    class OrderDetailDB
    {
        private static northwndEntities entities = new northwndEntities();

        // get all order details by order id
        public static List<Order_Detail> GetOrderDetails(int orderId)
        {
            List<Order_Detail> orderDetails = (from orderDetail in entities.Order_Details
                                                where orderDetail.OrderID == orderId
                                                select orderDetail).ToList();

            return orderDetails;
        }
    }
}
