﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using CustomerData;
using Json;

namespace CustomerData
{
    /* This is Utilities file to provide common functions which are used for the whole system.
       Author: Quynh Nguyen (Queenie)
       Date: Dec - 23 - 2018
     */
    public static class Utils
    {
        public enum CustomerTypeEnum { Residential = 'R', Commercial = 'C', Industrial = 'I'}; // Customer Types
        // Customer Type Names
        public static IDictionary<Char, String> CustomerTypeNames = new Dictionary<char, string>()
        {
            { 'R', "Residential" } , { 'C', "Commercial" }, { 'I', "Industrial" }
        };

        // states for writing data to file
        public const int SUCCESS = 1;
        public const int FAILURE = 0;
        public const int EXCEPTION = -1;

        // file name
        public static string customerFilePath = "customers.txt";

        // calculate bill for Residential Customer
        public static decimal CalculateBillForResidential(decimal kWhUsed)
        {
            // 6.00 - default price, 0.052 - unit price
            return 6.00m + 0.052m * kWhUsed;
        }

        // calculate bill for Industrial Customer
        public static decimal CalculateBillForIndustrial(decimal kWhPeekHourUsed, decimal kWhOffPeakHourUsed)
        {
            decimal result = 76; // default price even though kWhPeekHourUsed is zero

            // calculate charge for peak hour power used
            if (kWhPeekHourUsed > 1000)
            {
                result += (kWhPeekHourUsed - 1000m) * 0.065m;
            }

            // calculate charge for off-peak hour power used
            result += 40; // default price even though kWhOffPeakHourUsed is zero

            // different unit price is applied when power used is over 1000
            if (kWhOffPeakHourUsed > 1000)
            {
                result += (kWhOffPeakHourUsed - 1000m) * 0.028m;
            }

            return result;
        }

        // calculate bill for Commercial Customer
        public static decimal CalculateBillForCommercial(decimal kWhUsed)
        {
            decimal result = 60; // default value, even though power used is zero

            // different unit price is applied when power used is over 1000
            if (kWhUsed > 1000)
            {
                result += (kWhUsed - 1000m) * 0.045m;
            }

            return result;
        }

        // write customer data to file
        public static int WriteData(Customers custList)
        {
            FileStream fs = null;

            try
            {
                //JsonParser.Deserialize(); //json
                //JsonConvert.DeserializeObject<RootObject>(json);
                //open the file for writing  and overwrite old content.
                TextWriter writer = new StreamWriter(customerFilePath);

                XmlSerializer serializer = new XmlSerializer(typeof(Customers));
                serializer.Serialize(writer, custList); // serialize customers & store to file

                return SUCCESS;
            }
            catch
            {
                return EXCEPTION;
            }
            finally
            {
                if (fs != null) fs.Close();
            }
        }

        // Load customer data from file.
        public static Customers LoadCustomersFromFile()
        {
            Customers custList = new Customers();
            if (File.Exists(Utils.customerFilePath)) // load data when file exists
            {
                XmlSerializer reader = new XmlSerializer(typeof(Customers));
                StreamReader file = new StreamReader( Utils.customerFilePath);
                custList = (Customers)reader.Deserialize(file); // deserialize customers object from file data
                file.Close();
            }
            return custList;
        }
    }
}
