﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerData
{
    /* Define Residential Customer */
    [Serializable]
    public class ResidentialCustomer : Customer 
    {
        // construction
        public ResidentialCustomer() : base(-1, "", 'R', 0)
        {

        }

        public ResidentialCustomer(Int32 accountNo = -1, string customerName = "",
                        char customerType = 'R', decimal chargeAmount = 0) :
            base(accountNo, customerName, customerType, chargeAmount)
        {
            //no need to implement
        }

        // calculate bill for Residential Customer
        public override decimal CalculateCharge(decimal kwhPowerUsed, decimal kwhOffPeakPowerUsed = 0)
        {
            if (kwhPowerUsed >= 0)
            {
                // 6.00 - default price, 0.052 - unit price
                this.ChargeAmount = 6.00m + 0.052m * kwhPowerUsed;                
            }
            return this.ChargeAmount;
        }

        public override List<string> ToArrayOfValues()
        {
            List<string> result = new List<string>();
            result.Add(this.AccountNo.ToString());
            result.Add(this.CustomerName);
            result.Add("Residential");
            result.Add(this.ChargeAmount.ToString());
            return result;
        }
    }
}
