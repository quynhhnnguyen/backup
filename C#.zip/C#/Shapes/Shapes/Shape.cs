﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    public abstract class Shape // at least one abstract method exists
    {
        protected string id;

        public Shape() { }

        public Shape(string id)
        {
            this.id = id;
        }

        public abstract double CalculateArea();
       

    }
}
