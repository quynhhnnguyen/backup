USE [TravelExperts]
GO

/****** Object:  View [dbo].[PRODUCT_SUPPLIER]    Script Date: 2/11/2019 8:11:24 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [dbo].[PRODUCT_SUPPLIER] AS SELECT        dbo.Products_Suppliers.ProductSupplierId, dbo.Products.ProductId, dbo.Products.ProdName, dbo.Suppliers.SupplierId, dbo.Suppliers.SupName
FROM            dbo.Products_Suppliers INNER JOIN
                         dbo.Products ON dbo.Products.ProductId = dbo.Products_Suppliers.ProductId INNER JOIN
                         dbo.Suppliers ON dbo.Suppliers.SupplierId = dbo.Products_Suppliers.SupplierId
GO


