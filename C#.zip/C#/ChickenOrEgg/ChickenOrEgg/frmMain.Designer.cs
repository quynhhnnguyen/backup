﻿namespace ChickenOrEgg
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblFirstQuestion = new System.Windows.Forms.Label();
            this.grpBox = new System.Windows.Forms.GroupBox();
            this.radioBtnChicken = new System.Windows.Forms.RadioButton();
            this.radioBtnEgg = new System.Windows.Forms.RadioButton();
            this.pBDisplayImage = new System.Windows.Forms.PictureBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBDisplayImage)).BeginInit();
            this.SuspendLayout();
            // 
            // lblFirstQuestion
            // 
            this.lblFirstQuestion.AutoSize = true;
            this.lblFirstQuestion.Font = new System.Drawing.Font("Monotype Corsiva", 15.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFirstQuestion.ForeColor = System.Drawing.Color.Green;
            this.lblFirstQuestion.Location = new System.Drawing.Point(90, 48);
            this.lblFirstQuestion.Name = "lblFirstQuestion";
            this.lblFirstQuestion.Size = new System.Drawing.Size(150, 25);
            this.lblFirstQuestion.TabIndex = 0;
            this.lblFirstQuestion.Text = "What was first?";
            // 
            // grpBox
            // 
            this.grpBox.Controls.Add(this.radioBtnEgg);
            this.grpBox.Controls.Add(this.radioBtnChicken);
            this.grpBox.Location = new System.Drawing.Point(92, 84);
            this.grpBox.Name = "grpBox";
            this.grpBox.Size = new System.Drawing.Size(170, 92);
            this.grpBox.TabIndex = 1;
            this.grpBox.TabStop = false;
            this.grpBox.Text = "Select Your answer";
            // 
            // radioBtnChicken
            // 
            this.radioBtnChicken.AutoSize = true;
            this.radioBtnChicken.Location = new System.Drawing.Point(19, 27);
            this.radioBtnChicken.Name = "radioBtnChicken";
            this.radioBtnChicken.Size = new System.Drawing.Size(84, 24);
            this.radioBtnChicken.TabIndex = 0;
            this.radioBtnChicken.TabStop = true;
            this.radioBtnChicken.Text = "Chicken";
            this.radioBtnChicken.UseVisualStyleBackColor = true;
            this.radioBtnChicken.CheckedChanged += new System.EventHandler(this.radioBtnChicken_CheckedChanged);
            // 
            // radioBtnEgg
            // 
            this.radioBtnEgg.AutoSize = true;
            this.radioBtnEgg.Location = new System.Drawing.Point(20, 60);
            this.radioBtnEgg.Name = "radioBtnEgg";
            this.radioBtnEgg.Size = new System.Drawing.Size(56, 24);
            this.radioBtnEgg.TabIndex = 1;
            this.radioBtnEgg.TabStop = true;
            this.radioBtnEgg.Text = "Egg";
            this.radioBtnEgg.UseVisualStyleBackColor = true;
            this.radioBtnEgg.CheckedChanged += new System.EventHandler(this.radioBtnEgg_CheckedChanged);
            // 
            // pBDisplayImage
            // 
            this.pBDisplayImage.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pBDisplayImage.Location = new System.Drawing.Point(324, 58);
            this.pBDisplayImage.Name = "pBDisplayImage";
            this.pBDisplayImage.Size = new System.Drawing.Size(229, 117);
            this.pBDisplayImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBDisplayImage.TabIndex = 2;
            this.pBDisplayImage.TabStop = false;
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(161, 195);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(78, 29);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(699, 326);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.pBDisplayImage);
            this.Controls.Add(this.grpBox);
            this.Controls.Add(this.lblFirstQuestion);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmMain";
            this.Text = "Important Question";
            this.grpBox.ResumeLayout(false);
            this.grpBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pBDisplayImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblFirstQuestion;
        private System.Windows.Forms.GroupBox grpBox;
        private System.Windows.Forms.RadioButton radioBtnEgg;
        private System.Windows.Forms.RadioButton radioBtnChicken;
        private System.Windows.Forms.PictureBox pBDisplayImage;
        private System.Windows.Forms.Button btnExit;
    }
}

