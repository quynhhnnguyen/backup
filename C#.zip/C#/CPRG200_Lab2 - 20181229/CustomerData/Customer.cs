﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerData
{
    [Serializable]
    public abstract class Customer
    {
        private int accountNo;
        private string customerName;
        private char customerType;
        private decimal chargeAmount;

        public Customer()
        {
            this.accountNo = -1;
            this.customerName = "";
            this.customerType = 'R';
            this.chargeAmount = 0;
        }

        public Customer(int accountNo = -1, string customerName = "",
                        char customerType = 'R', decimal chargeAmount = 0)
        {
            this.accountNo = accountNo;
            this.customerName = customerName;
            this.customerType = customerType;
            this.chargeAmount = chargeAmount;
        }

        public string CustomerName
        {
            get { return this.customerName; }
            set
            {   //customer Name should be non-empty string
                if (!String.IsNullOrEmpty(value))
                    this.customerName = value;
            }
        }

        public int AccountNo
        {
            get { return this.accountNo; }
            set
            {
                // account Number should be a positive integer value
                int number;
                if (Int32.TryParse(value.ToString(), out number) && number > 0)
                {
                    this.accountNo = value;
                }     
            }
        }

        public char CustomerType
        {
            get { return this.customerType; }
            set
            {
                if (Char.IsLetter(value))
                    this.customerType = value;
            }
        }

        public decimal ChargeAmount
        {
            get { return this.chargeAmount; }
            set
            {
                decimal number = 0;
                if (Decimal.TryParse(value.ToString(), out number) && number > 0)
                    this.chargeAmount = number;
            }
        }

        //public abstract decimal CalculateCharge(decimal kwhPowerUsed);
        public abstract decimal CalculateCharge(decimal kwhPowerUsed, decimal kwhOffPeakPowerUsed = 0);
        //{ return 0; }

        public override string ToString()
        {
            return "AccountNo: " + this.accountNo + ", Customer Name: " + this.customerName +
                    ", Customer Type: " + /*Utils.CustomerTypeNames[this.customerType]*/
                    this.customerType  +
                    ", Charge Amount: " + this.chargeAmount;
        }

        /* Generate xml string from object Customer */
        public string ToXMLString()
        {
            return "<customer>" +
                        "<accountNo>" + this.accountNo + "</accountNo>" +
                        "<customerName>" + this.customerName + "</customerName>" +
                        "<customerType>" + this.customerType + "</customerType>" +
                        "<chargeAmount>" + this.chargeAmount + "</chargeAmount>" +
                   "</customer>";
        }

        public abstract List<string> ToArrayOfValues();
        /*{
            List<string> result = new List<string>();
            result.Add(this.accountNo.ToString());
            result.Add(this.customerName);
            result.Add(this.customerType.ToString());
            result.Add(this.ChargeAmount.ToString());
            return result;
        }*/
    }
}
 