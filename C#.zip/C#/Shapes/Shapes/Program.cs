﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shapes
{
    class Program
    {
        static void Main(string[] args)
        {
            Circle c1 = new Circle("c1", 2);
            Console.WriteLine(c1);

            Circle c2 = new Circle("c2", 5.5);
            Console.WriteLine(c2);

            Rectangle r1 = new Rectangle("r1", 3, 4);
            Console.WriteLine(r1);

            Rectangle r2 = new Rectangle("r2", 5.5, 2);
            Console.WriteLine(r2);

            Console.WriteLine("\n MAKING A LIST OF SHAPE:");
            List<Shape> shapes = new List<Shape>();
            shapes.Add(c1);
            shapes.Add(c2);
            shapes.Add(r1);
            shapes.Add(r2);

            foreach(Shape shape in shapes)
            {
                Console.WriteLine(shape);
            }

            Console.WriteLine("\n Press any Key to Exit");
            Console.ReadKey();
        }
    }
}
