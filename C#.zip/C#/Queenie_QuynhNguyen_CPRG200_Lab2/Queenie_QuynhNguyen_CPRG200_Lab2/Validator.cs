﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Queenie_QuynhNguyen_CPRG200_Lab2
{
    /* This class is used for input value validation
      Author: Quynh Nguyen (Queenie)
      Date: Dec - 05 - 2018
    */
    static class Validator
    {
        // tests if input is a non-negative number.
        public static bool IsNonNegativeNumber(TextBox tb, string name)
        {
            bool result = true;
            decimal number; // parsed number

            if(!Decimal.TryParse(tb.Text, out number))
            {
                result = false;
                MessageBox.Show(name + " has to be a number", "Data Entry Error");
                tb.SelectAll(); // select all text to facilitate change
                tb.Focus();
            } else // it's number, check whether it is negative or not
            {
                if(number < 0)
                {
                    result = false;
                    MessageBox.Show(name + " has to be a non-negative number", "Data Entry Error");
                    tb.SelectAll(); // select all text to facilitate change
                    tb.Focus();
                }
            }          

            return result;
        }

        // tests if a textbox is not empty (required fields)
        public static bool IsProvided(TextBox tb, string name)
        {
            bool result = true;
            if (Convert.IsDBNull(tb))
            {
                result = false;
                tb.Focus();
                MessageBox.Show("The text box - " + name + " is empty.");
            }
            return result;
        }

        public static bool IsProvided(ComboBox cbb, string name)
        {
            bool result = true;
            if (cbb.SelectedIndex == -1)
            {
                result = false;
                cbb.Focus();
                MessageBox.Show("Please choose Customer Type from Selection Box.");
            }
            return result;
        }
    }
}
