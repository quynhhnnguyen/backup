﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueenieNguyen_CPRG200_Lab4
{
    /* Utilities class
     * Author: Queenie Nguyen
     * Created Date: Jan - 11 - 2019
     */
    public static class Utils
    {
        // convert object value to string and null handling
        public static string ConvertToString(object obj)
        {
            if (obj == null)
                return "";
            else
                return Convert.ToString(obj);
        }

        // null date time handling
        public static DateTime ConvertToDateTime(Nullable<DateTime> date)
        {
            if (date == null)
                return DateTime.Now;
            else
                return Convert.ToDateTime(date);
        }

        // calculate  order total
        public static decimal CalculateOrderTotal(List<Order_Detail> orderDetails)
        {
            decimal result = 0;
            if(orderDetails != null)
                foreach(Order_Detail orderDetail in orderDetails)
                {
                    result += (decimal)orderDetail.UnitPrice * (1 - (decimal)orderDetail.Discount) * orderDetail.Quantity;
                }

            return result;
        }
    }
}
