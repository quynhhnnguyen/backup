﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Queenie_QuynhNguyen_CPRG200_Lab3
{
    public partial class frmData : Form
    {
        public frmData()
        {
            InitializeComponent();
        }

        // Data Loading when Form is loading
        private void frmData_Load(object sender, EventArgs e)
        {
            try
            {
                // TODO: This line of code loads data into the 'northwndDataSet.Categories' table. You can move, or remove it, as needed.
                this.categoriesTableAdapter.Fill(this._northwnd__2_DataSet.Categories);
                // TODO: This line of code loads data into the 'northwndDataSet.Suppliers' table. You can move, or remove it, as needed.
                this.suppliersTableAdapter.Fill(this._northwnd__2_DataSet.Suppliers);
                // TODO: This line of code loads data into the 'northwndDataSet.Order_Details' table. You can move, or remove it, as needed.
                this.order_DetailsTableAdapter.Fill(this._northwnd__2_DataSet.Order_Details);
                // TODO: This line of code loads data into the 'northwndDataSet.Products' table. You can move, or remove it, as needed.
                this.productsTableAdapter.Fill(this._northwnd__2_DataSet.Products);
            }
            catch (SqlException ex)// any exception coming from data provider
            {
                MessageBox.Show("Database exception while saving data: " +
                    ex.Message, ex.GetType().ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Other error while saving data: " +
                    ex.Message, ex.GetType().ToString());
            }


        }

        // Save Button clicked handling
        private void productsBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            try
            {
                this.Validate();
                this.productsBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this._northwnd__2_DataSet);
            }
            catch (DBConcurrencyException)
            {
                MessageBox.Show("Another user updated or deleted data. Try again",
                    "Concurrency Error");
            }
            catch (SqlException ex)// any exception coming from data provider
            {
                MessageBox.Show("Database exception while saving data: " +
                    ex.Message, ex.GetType().ToString());
            }
            catch (NoNullAllowedException ex)
            {   // try to save empty value for database required field
                MessageBox.Show("Error while validating data: " +
                    ex.Message, ex.GetType().ToString());
            }
            catch (ArgumentException ex)
            {
                // input data's lenght is over database column limitation
                MessageBox.Show("Error while validating data: " +
                    ex.Message, ex.GetType().ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Other error while saving data: " +
                    ex.Message, ex.GetType().ToString());
            }


        }

        // Add New item clicked
        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            // assign value to discontinued checkbox
            discontinuedCheckBox.Checked = false;
        }

    }
}
