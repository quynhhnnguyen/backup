﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerData
{
    [Serializable]
    public class CommercialCustomers
    {
        private List<CommercialCustomer> customers = new List<CommercialCustomer>();
 
        public List<CommercialCustomer> Customers
        {
            get { return this.customers; }
            set { this.customers = value; }
        }

        public string[] getTotalNumbers()
        {
            decimal totalOfCharge = 0;
            string[] rCustomers = { "Commercial", customers.Count.ToString(), totalOfCharge.ToString() };

            foreach (CommercialCustomer cust in customers)
            {
                totalOfCharge += cust.ChargeAmount;
            }
            rCustomers[2] = totalOfCharge.ToString();
            return rCustomers;
        }

        public ArrayList getCustomersInfo()
        {
            ArrayList result = new ArrayList();
            foreach (CommercialCustomer cust in customers)
            {
                result.Add(cust.ToArrayOfValues().ToArray());
            }
            return result;
        }
    }
}
