﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QueenieNguyen_CPRG200_Lab4
{
    /* This Application Allows User view Order information and update the shipped date
     * Author: Queenie Nguyen
     * Created Date: Jan - 11 - 2019
     */
    public partial class frmMain : Form
    {
        //variable declaration
        Order order = null;

        public frmMain()
        {
            InitializeComponent();
        }

        // form load handling
        private void frmMain_Load(object sender, EventArgs e)
        {
            try
            {
                //set focus on order id combo box
                orderIDComboBox.Focus();
                // load order Id list
                orderIDComboBox.DataSource = OrderDB.GetOrderIDs();
            }
            catch(Exception ex)
            {
                // Error handling
                MessageBox.Show("Error happens: " + ex.Message, ex.GetType().ToString());
            }
        }

        // order Id change handling
        private void orderIDComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int orderId = Convert.ToInt32(orderIDComboBox.SelectedValue);
                List<Order_Detail> orderDetails = OrderDetailDB.GetOrderDetails(orderId); // get order details
                order_DetailDataGridView.DataSource = orderDetails;
                txtOrderTotal.Text = Utils.CalculateOrderTotal(orderDetails).ToString("c"); // calculate order total
                DisplayOrder(orderId);
            }
            catch(Exception ex)
            {
                //Error Handling
                MessageBox.Show("Error happens: " + ex.Message, ex.GetType().ToString());
            }
            
        }

        // display order information
        private void DisplayOrder(int orderId)
        { 
            order = OrderDB.GetOrder(orderId);
            customerIDTextBox.Text = Utils.ConvertToString(order.CustomerID);
            orderDateDateTimePicker.Value = Utils.ConvertToDateTime(order.OrderDate);
            requiredDateDateTimePicker.Value = Utils.ConvertToDateTime(order.RequiredDate);
            //shippedDateDateTimePicker.Value = Utils.ConvertToDateTime(order.ShippedDate);
            //Checking Null value for shipping date
            if (order.ShippedDate == null)
            {
                shippedDateDateTimePicker.CustomFormat = " ";
                shippedDateDateTimePicker.Format = DateTimePickerFormat.Custom;
            }
            else
            {
                shippedDateDateTimePicker.Format = DateTimePickerFormat.Long;
                shippedDateDateTimePicker.Value = (DateTime)(order.ShippedDate);
            }
        }

        // save shipped date to database
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                // validate shipped date
                if (orderDateDateTimePicker.Value.CompareTo(shippedDateDateTimePicker.Value) > 0 ||
                requiredDateDateTimePicker.Value.CompareTo(shippedDateDateTimePicker.Value) < 0)
                {
                    MessageBox.Show("Shipped Date could not be ealier than Order Date nor later than Required Date.");
                }
                else
                {
                    bool updateResult = OrderDB.UpdateShippedDate(order.OrderID, shippedDateDateTimePicker.Value);
                    if(updateResult)
                    {
                        MessageBox.Show("Order was updated successfully.");
                    }
                    else
                    {
                        MessageBox.Show("Order was not updated successfully.");
                    }
                }
                    
            }
            catch (Exception ex)
            {
                //Error Handling
                MessageBox.Show("Error happens: " + ex.Message, ex.GetType().ToString());
            }
            
        }

    }
}
