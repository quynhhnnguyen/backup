﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerData
{
    /* This is an Industrial Customer Object.
       Author: Quynh Nguyen (Queenie)
       Date: Dec - 23 - 2018
     */
    [Serializable]
    public class IndustrialCustomer : Customer
    {
        // construction
        public IndustrialCustomer() : base(-1, "", 'I', 0)
        {

        }

        // construction
        public IndustrialCustomer(Int32 accountNo = -1, string customerName = "",
                        char customerType = 'I', decimal chargeAmount = 0) :
            base(accountNo, customerName, customerType, chargeAmount)
        {
            //no need to implement
        }

        // Overload method - calculate charge from kwh Peak hour Power Used and kwh Off-Peak hour Power Used
        public override decimal CalculateCharge(decimal kwhPowerUsed, decimal kwhOffPeakUsed = 0)
        {
            if(kwhPowerUsed < 0 || kwhOffPeakUsed < 0)
            {
                return this.ChargeAmount;
            }

            this.ChargeAmount = Utils.CalculateBillForIndustrial(kwhPowerUsed, kwhOffPeakUsed);

            return this.ChargeAmount;
        }

        // generate array of customer data
        public override List<string> ToArrayOfValues()
        {
            List<string> result = new List<string>();
            result.Add(this.AccountNo.ToString());
            result.Add(this.CustomerName);
            result.Add("Industrial");
            result.Add(this.ChargeAmount.ToString());
            return result;
        }
    }
}
