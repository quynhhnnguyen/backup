﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
    class Employee
    {
        const decimal OT_RATE = 1.5m;
        const decimal FULL_WEEK = 37.5m;

        // private data
        private string name;
        private decimal hours; // hours worked
        private decimal payRate; // pay per hour

        //constructor
        public Employee(string name, decimal hours, decimal payRate)
        {
            this.name = name;
            this.hours = hours;
            this.payRate = payRate;
        }

        //public method
        public virtual decimal CalculatePay() //virtual - can be overridden
        {
            if(hours<=FULL_WEEK)
            {
                return hours * payRate;
            }
            else // overtime applies
            {
                return FULL_WEEK * payRate +
                    (hours - FULL_WEEK) * payRate * OT_RATE;
            }
        }

        public override string ToString()
        {
            return "\n Name:" + name + 
                   "\n Worked Hours: " + hours.ToString() +
                   "\n Pay Rate: " + payRate.ToString("c");
        }
        
    }
}
