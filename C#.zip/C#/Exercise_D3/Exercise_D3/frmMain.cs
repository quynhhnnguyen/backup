﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Exercise_D3
{
    public partial class frmMain : Form
    {
        //array of numbers
        const int MAX_SIZE = 20;
        double[] values = new double[MAX_SIZE];
        int count = 0;
        double total = 0.0;

        public frmMain()
        {
            InitializeComponent();
        }

        private void lstBValues_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            // get sequence of decimal numbers and store to array.
            string inputValue = txtNumbers.Text;
            string[] parsedValues = new string[MAX_SIZE];

            //validate ... later
            parsedValues = inputValue.Split(',');
            foreach (string value in parsedValues)
            {
                if (value != "")
                {
                    lstBValues.Items.Add(value); //should validate data before adding.
                    values[count] = Convert.ToDouble(value);
                    total += Convert.ToDouble(value);
                    count++;
                }

            }

            DisplayData();
        }


        private void btnReset_Click(object sender, EventArgs e)
        {
            txtNumbers.Text = "";
            txtCount.Text = "";
            txtTotal.Text = "";
            lstBValues.Items.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // as the application starts, read data from the file and display
        private void frmMain_Load(object sender, EventArgs e)
        {
            count = FileIO.ReadData(values);
            DisplayData();

        }

        //displays current content of the array in list box
        //displays count and total
        private void DisplayData()
        {
            lstBValues.Items.Clear(); // start with empty list box
            for(int i=0; i<count; i++) // for each number in the array
            {
                lstBValues.Items.Add(values[i]); // add it into list box
                total += values[i];
            }

            txtCount.Text = count.ToString(); // display counter
            txtTotal.Text = total.ToString(); // display total
        }

        // save data as the form closes
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            FileIO.WriteData(values, count);
        }
    }
}
