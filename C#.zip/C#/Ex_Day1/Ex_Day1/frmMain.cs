﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex_Day1
{
    public partial class frmMain : Form
    {
        /* This App is used to calculate Salary based on Worked Hours and Hourly Rate
         * Author: Quynh Nguyen (Queenie)
         * Date: Dec - 03 - 2018
         */

        const double REG_HOURS = 37.5; // Regular hours
        const double OT_RATIO = 1.5; // Overtime Ratio

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        // Calculate Salary based on Worked Hours and Hourly Rate
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // should validate input data before converting
            double workedHours = Convert.ToDouble(txtWorkedHours.Text); //worked hours
            double hourlyRate = Convert.ToDouble(txtHourlyRate.Text); // hourly rate

            //double.TryParse(txtWorkedHours.Text, workedHours) ? Convert.ToDouble(txtWorkedHours.Text) : 0.0; 
            if (workedHours > REG_HOURS)
            {
                txtOverTimePay.Text = ((workedHours - REG_HOURS) * hourlyRate * 1.5).ToString("c");
                txtRegularPay.Text = (REG_HOURS * hourlyRate).ToString("c");
                txtTotalPay.Text = (((workedHours - REG_HOURS) * hourlyRate * 1.5)
                                        + (REG_HOURS * hourlyRate)).ToString("c");
                grpBRegPay.Show();
                grpBOTPay.Show();
                grpBTotalPay.Show();
            } else
            {
                txtRegularPay.Text = (workedHours * hourlyRate).ToString("c");
                grpBRegPay.Show();
                grpBOTPay.Hide();
                grpBTotalPay.Hide();
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtWorkedHours.Text = "";
            txtHourlyRate.Text = "";
            txtWorkedHours.Focus();
            grpBRegPay.Hide();
            grpBOTPay.Hide();
            grpBTotalPay.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
