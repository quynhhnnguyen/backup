﻿namespace Queenie_QuynhNguyen_CPRG200_Lab2
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPageCaption = new System.Windows.Forms.Label();
            this.lblPowerUsed = new System.Windows.Forms.Label();
            this.txtPowerUsed = new System.Windows.Forms.TextBox();
            this.lblCustomerType = new System.Windows.Forms.Label();
            this.cbbCustomerType = new System.Windows.Forms.ComboBox();
            this.lblEstimatedCharge = new System.Windows.Forms.Label();
            this.txtEstimatedCharge = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpBoxPeakHour = new System.Windows.Forms.GroupBox();
            this.txtOffPeakHours = new System.Windows.Forms.TextBox();
            this.lblOffPeakHours = new System.Windows.Forms.Label();
            this.grpBInfo = new System.Windows.Forms.GroupBox();
            this.txtOffPeakInfo = new System.Windows.Forms.TextBox();
            this.txtPowerUsedInfo = new System.Windows.Forms.TextBox();
            this.lblOffPeakInfo = new System.Windows.Forms.Label();
            this.lblPowerUsedInfo = new System.Windows.Forms.Label();
            this.lblAccountNo = new System.Windows.Forms.Label();
            this.txtAccountNo = new System.Windows.Forms.TextBox();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.grpBCustomerInfo = new System.Windows.Forms.GroupBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.dataGridCustInfo = new System.Windows.Forms.DataGridView();
            this.dtGVTotalInfo = new System.Windows.Forms.DataGridView();
            this.AccountNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CustomerType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ChargeAmount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtTotalOfAllCharge = new System.Windows.Forms.TextBox();
            this.lblSumAll = new System.Windows.Forms.Label();
            this.grpBoxPeakHour.SuspendLayout();
            this.grpBInfo.SuspendLayout();
            this.grpBCustomerInfo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCustInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtGVTotalInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPageCaption
            // 
            this.lblPageCaption.AutoSize = true;
            this.lblPageCaption.Font = new System.Drawing.Font("Monotype Corsiva", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageCaption.Location = new System.Drawing.Point(164, 7);
            this.lblPageCaption.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPageCaption.Name = "lblPageCaption";
            this.lblPageCaption.Size = new System.Drawing.Size(437, 57);
            this.lblPageCaption.TabIndex = 0;
            this.lblPageCaption.Text = "Power Bill Calculation";
            // 
            // lblPowerUsed
            // 
            this.lblPowerUsed.AutoSize = true;
            this.lblPowerUsed.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPowerUsed.Location = new System.Drawing.Point(67, 112);
            this.lblPowerUsed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPowerUsed.Name = "lblPowerUsed";
            this.lblPowerUsed.Size = new System.Drawing.Size(162, 20);
            this.lblPowerUsed.TabIndex = 1;
            this.lblPowerUsed.Text = "Power Used (kWh):";
            // 
            // txtPowerUsed
            // 
            this.txtPowerUsed.Location = new System.Drawing.Point(282, 112);
            this.txtPowerUsed.Name = "txtPowerUsed";
            this.txtPowerUsed.Size = new System.Drawing.Size(212, 24);
            this.txtPowerUsed.TabIndex = 2;
            // 
            // lblCustomerType
            // 
            this.lblCustomerType.AutoSize = true;
            this.lblCustomerType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerType.Location = new System.Drawing.Point(94, 151);
            this.lblCustomerType.Name = "lblCustomerType";
            this.lblCustomerType.Size = new System.Drawing.Size(134, 20);
            this.lblCustomerType.TabIndex = 8;
            this.lblCustomerType.Text = "Customer Type:";
            // 
            // cbbCustomerType
            // 
            this.cbbCustomerType.DisplayMember = "0,1,2";
            this.cbbCustomerType.FormattingEnabled = true;
            this.cbbCustomerType.Items.AddRange(new object[] {
            "Residential",
            "Commercial",
            "Industrial"});
            this.cbbCustomerType.Location = new System.Drawing.Point(283, 147);
            this.cbbCustomerType.Name = "cbbCustomerType";
            this.cbbCustomerType.Size = new System.Drawing.Size(210, 26);
            this.cbbCustomerType.TabIndex = 9;
            this.cbbCustomerType.ValueMember = "0,1,2";
            this.cbbCustomerType.SelectedIndexChanged += new System.EventHandler(this.cbbCustomerType_SelectedIndexChanged);
            // 
            // lblEstimatedCharge
            // 
            this.lblEstimatedCharge.AutoSize = true;
            this.lblEstimatedCharge.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstimatedCharge.Location = new System.Drawing.Point(61, 34);
            this.lblEstimatedCharge.Name = "lblEstimatedCharge";
            this.lblEstimatedCharge.Size = new System.Drawing.Size(125, 15);
            this.lblEstimatedCharge.TabIndex = 10;
            this.lblEstimatedCharge.Text = "Estimated Charge:";
            // 
            // txtEstimatedCharge
            // 
            this.txtEstimatedCharge.Enabled = false;
            this.txtEstimatedCharge.Location = new System.Drawing.Point(192, 28);
            this.txtEstimatedCharge.Name = "txtEstimatedCharge";
            this.txtEstimatedCharge.ReadOnly = true;
            this.txtEstimatedCharge.Size = new System.Drawing.Size(117, 24);
            this.txtEstimatedCharge.TabIndex = 11;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(281, 245);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(96, 24);
            this.btnCalculate.TabIndex = 12;
            this.btnCalculate.Text = "&Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(383, 245);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(80, 24);
            this.btnReset.TabIndex = 13;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(678, 33);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(76, 24);
            this.btnExit.TabIndex = 14;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // grpBoxPeakHour
            // 
            this.grpBoxPeakHour.Controls.Add(this.txtOffPeakHours);
            this.grpBoxPeakHour.Controls.Add(this.lblOffPeakHours);
            this.grpBoxPeakHour.Location = new System.Drawing.Point(23, 178);
            this.grpBoxPeakHour.Name = "grpBoxPeakHour";
            this.grpBoxPeakHour.Size = new System.Drawing.Size(524, 45);
            this.grpBoxPeakHour.TabIndex = 15;
            this.grpBoxPeakHour.TabStop = false;
            this.grpBoxPeakHour.Visible = false;
            // 
            // txtOffPeakHours
            // 
            this.txtOffPeakHours.Location = new System.Drawing.Point(260, 11);
            this.txtOffPeakHours.Name = "txtOffPeakHours";
            this.txtOffPeakHours.Size = new System.Drawing.Size(212, 24);
            this.txtOffPeakHours.TabIndex = 16;
            // 
            // lblOffPeakHours
            // 
            this.lblOffPeakHours.AutoSize = true;
            this.lblOffPeakHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOffPeakHours.Location = new System.Drawing.Point(4, 13);
            this.lblOffPeakHours.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOffPeakHours.Name = "lblOffPeakHours";
            this.lblOffPeakHours.Size = new System.Drawing.Size(227, 20);
            this.lblOffPeakHours.TabIndex = 4;
            this.lblOffPeakHours.Text = "Off Peak Hour Used (kWh):";
            // 
            // grpBInfo
            // 
            this.grpBInfo.Controls.Add(this.txtOffPeakInfo);
            this.grpBInfo.Controls.Add(this.txtPowerUsedInfo);
            this.grpBInfo.Controls.Add(this.lblOffPeakInfo);
            this.grpBInfo.Controls.Add(this.lblPowerUsedInfo);
            this.grpBInfo.Controls.Add(this.lblEstimatedCharge);
            this.grpBInfo.Controls.Add(this.txtEstimatedCharge);
            this.grpBInfo.Location = new System.Drawing.Point(678, 87);
            this.grpBInfo.Name = "grpBInfo";
            this.grpBInfo.Size = new System.Drawing.Size(328, 188);
            this.grpBInfo.TabIndex = 16;
            this.grpBInfo.TabStop = false;
            this.grpBInfo.Text = "Estimated  Power Bill Without GST:";
            this.grpBInfo.Visible = false;
            // 
            // txtOffPeakInfo
            // 
            this.txtOffPeakInfo.Enabled = false;
            this.txtOffPeakInfo.Location = new System.Drawing.Point(192, 89);
            this.txtOffPeakInfo.Name = "txtOffPeakInfo";
            this.txtOffPeakInfo.Size = new System.Drawing.Size(117, 24);
            this.txtOffPeakInfo.TabIndex = 17;
            this.txtOffPeakInfo.Visible = false;
            // 
            // txtPowerUsedInfo
            // 
            this.txtPowerUsedInfo.Enabled = false;
            this.txtPowerUsedInfo.Location = new System.Drawing.Point(192, 60);
            this.txtPowerUsedInfo.Name = "txtPowerUsedInfo";
            this.txtPowerUsedInfo.Size = new System.Drawing.Size(117, 24);
            this.txtPowerUsedInfo.TabIndex = 17;
            // 
            // lblOffPeakInfo
            // 
            this.lblOffPeakInfo.AutoSize = true;
            this.lblOffPeakInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOffPeakInfo.Location = new System.Drawing.Point(7, 95);
            this.lblOffPeakInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOffPeakInfo.Name = "lblOffPeakInfo";
            this.lblOffPeakInfo.Size = new System.Drawing.Size(178, 15);
            this.lblOffPeakInfo.TabIndex = 12;
            this.lblOffPeakInfo.Text = "Off Peak Hour Used (kWh):";
            this.lblOffPeakInfo.Visible = false;
            // 
            // lblPowerUsedInfo
            // 
            this.lblPowerUsedInfo.AutoSize = true;
            this.lblPowerUsedInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPowerUsedInfo.Location = new System.Drawing.Point(41, 66);
            this.lblPowerUsedInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPowerUsedInfo.Name = "lblPowerUsedInfo";
            this.lblPowerUsedInfo.Size = new System.Drawing.Size(129, 15);
            this.lblPowerUsedInfo.TabIndex = 11;
            this.lblPowerUsedInfo.Text = "Power Used (kWh):";
            // 
            // lblAccountNo
            // 
            this.lblAccountNo.AutoSize = true;
            this.lblAccountNo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAccountNo.Location = new System.Drawing.Point(122, 32);
            this.lblAccountNo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAccountNo.Name = "lblAccountNo";
            this.lblAccountNo.Size = new System.Drawing.Size(107, 20);
            this.lblAccountNo.TabIndex = 17;
            this.lblAccountNo.Text = "Account No:";
            // 
            // txtAccountNo
            // 
            this.txtAccountNo.Location = new System.Drawing.Point(281, 30);
            this.txtAccountNo.Name = "txtAccountNo";
            this.txtAccountNo.Size = new System.Drawing.Size(212, 24);
            this.txtAccountNo.TabIndex = 18;
            // 
            // lblCustomerName
            // 
            this.lblCustomerName.AutoSize = true;
            this.lblCustomerName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerName.Location = new System.Drawing.Point(87, 69);
            this.lblCustomerName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCustomerName.Name = "lblCustomerName";
            this.lblCustomerName.Size = new System.Drawing.Size(142, 20);
            this.lblCustomerName.TabIndex = 19;
            this.lblCustomerName.Text = "Customer Name:";
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Location = new System.Drawing.Point(281, 64);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(212, 24);
            this.txtCustomerName.TabIndex = 20;
            // 
            // grpBCustomerInfo
            // 
            this.grpBCustomerInfo.Controls.Add(this.btnAdd);
            this.grpBCustomerInfo.Controls.Add(this.txtAccountNo);
            this.grpBCustomerInfo.Controls.Add(this.txtCustomerName);
            this.grpBCustomerInfo.Controls.Add(this.lblPowerUsed);
            this.grpBCustomerInfo.Controls.Add(this.lblCustomerName);
            this.grpBCustomerInfo.Controls.Add(this.txtPowerUsed);
            this.grpBCustomerInfo.Controls.Add(this.lblCustomerType);
            this.grpBCustomerInfo.Controls.Add(this.lblAccountNo);
            this.grpBCustomerInfo.Controls.Add(this.cbbCustomerType);
            this.grpBCustomerInfo.Controls.Add(this.btnCalculate);
            this.grpBCustomerInfo.Controls.Add(this.grpBoxPeakHour);
            this.grpBCustomerInfo.Controls.Add(this.btnReset);
            this.grpBCustomerInfo.Location = new System.Drawing.Point(85, 87);
            this.grpBCustomerInfo.Name = "grpBCustomerInfo";
            this.grpBCustomerInfo.Size = new System.Drawing.Size(581, 289);
            this.grpBCustomerInfo.TabIndex = 0;
            this.grpBCustomerInfo.TabStop = false;
            this.grpBCustomerInfo.Text = "Customer Information:";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(469, 245);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(54, 24);
            this.btnAdd.TabIndex = 17;
            this.btnAdd.Text = "&Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // dataGridCustInfo
            // 
            this.dataGridCustInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridCustInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.AccountNo,
            this.CustomerName,
            this.CustomerType,
            this.ChargeAmount});
            this.dataGridCustInfo.Location = new System.Drawing.Point(85, 527);
            this.dataGridCustInfo.Name = "dataGridCustInfo";
            this.dataGridCustInfo.Size = new System.Drawing.Size(654, 151);
            this.dataGridCustInfo.TabIndex = 17;
            // 
            // dtGVTotalInfo
            // 
            this.dtGVTotalInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtGVTotalInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
            this.dtGVTotalInfo.Location = new System.Drawing.Point(85, 402);
            this.dtGVTotalInfo.Name = "dtGVTotalInfo";
            this.dtGVTotalInfo.Size = new System.Drawing.Size(516, 119);
            this.dtGVTotalInfo.TabIndex = 19;
            // 
            // AccountNo
            // 
            this.AccountNo.HeaderText = "Account No";
            this.AccountNo.Name = "AccountNo";
            this.AccountNo.Width = 121;
            // 
            // CustomerName
            // 
            this.CustomerName.HeaderText = "Customer Name";
            this.CustomerName.Name = "CustomerName";
            this.CustomerName.Width = 170;
            // 
            // CustomerType
            // 
            this.CustomerType.HeaderText = "Customer Type";
            this.CustomerType.Name = "CustomerType";
            this.CustomerType.Width = 160;
            // 
            // ChargeAmount
            // 
            this.ChargeAmount.HeaderText = "Charge Amount";
            this.ChargeAmount.Name = "ChargeAmount";
            this.ChargeAmount.Width = 160;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.ColumnHeader;
            this.dataGridViewTextBoxColumn1.HeaderText = "Customer Type";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.Width = 135;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.HeaderText = "Total of Customer";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Width = 170;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.HeaderText = "Total of Charge";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.Width = 160;
            // 
            // txtTotalOfAllCharge
            // 
            this.txtTotalOfAllCharge.Enabled = false;
            this.txtTotalOfAllCharge.Location = new System.Drawing.Point(619, 424);
            this.txtTotalOfAllCharge.Name = "txtTotalOfAllCharge";
            this.txtTotalOfAllCharge.Size = new System.Drawing.Size(135, 24);
            this.txtTotalOfAllCharge.TabIndex = 20;
            // 
            // lblSumAll
            // 
            this.lblSumAll.AutoSize = true;
            this.lblSumAll.Location = new System.Drawing.Point(616, 403);
            this.lblSumAll.Name = "lblSumAll";
            this.lblSumAll.Size = new System.Drawing.Size(153, 18);
            this.lblSumAll.TabIndex = 21;
            this.lblSumAll.Text = "Total of All Charge:";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1051, 690);
            this.Controls.Add(this.lblSumAll);
            this.Controls.Add(this.txtTotalOfAllCharge);
            this.Controls.Add(this.dtGVTotalInfo);
            this.Controls.Add(this.dataGridCustInfo);
            this.Controls.Add(this.grpBCustomerInfo);
            this.Controls.Add(this.grpBInfo);
            this.Controls.Add(this.lblPageCaption);
            this.Controls.Add(this.btnExit);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMain";
            this.Text = "Power Bill Calculation";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.grpBoxPeakHour.ResumeLayout(false);
            this.grpBoxPeakHour.PerformLayout();
            this.grpBInfo.ResumeLayout(false);
            this.grpBInfo.PerformLayout();
            this.grpBCustomerInfo.ResumeLayout(false);
            this.grpBCustomerInfo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridCustInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtGVTotalInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPageCaption;
        private System.Windows.Forms.Label lblPowerUsed;
        private System.Windows.Forms.TextBox txtPowerUsed;
        private System.Windows.Forms.Label lblCustomerType;
        private System.Windows.Forms.ComboBox cbbCustomerType;
        private System.Windows.Forms.Label lblEstimatedCharge;
        private System.Windows.Forms.TextBox txtEstimatedCharge;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.GroupBox grpBoxPeakHour;
        private System.Windows.Forms.TextBox txtOffPeakHours;
        private System.Windows.Forms.Label lblOffPeakHours;
        private System.Windows.Forms.GroupBox grpBInfo;
        private System.Windows.Forms.TextBox txtPowerUsedInfo;
        private System.Windows.Forms.Label lblOffPeakInfo;
        private System.Windows.Forms.Label lblPowerUsedInfo;
        private System.Windows.Forms.TextBox txtOffPeakInfo;
        private System.Windows.Forms.Label lblAccountNo;
        private System.Windows.Forms.TextBox txtAccountNo;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.GroupBox grpBCustomerInfo;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dataGridCustInfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn AccountNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerName;
        private System.Windows.Forms.DataGridViewTextBoxColumn CustomerType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ChargeAmount;
        private System.Windows.Forms.DataGridView dtGVTotalInfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.TextBox txtTotalOfAllCharge;
        private System.Windows.Forms.Label lblSumAll;
    }
}

