﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee("Bob", 35, 20);
            Console.WriteLine(emp);
            Console.WriteLine("Pay amount: " + emp.CalculatePay().ToString("c"));

            Employee emp1 = new Employee("Ann", 40, 20);
            Console.WriteLine(emp1);
            Console.WriteLine("Pay amount: " + emp1.CalculatePay().ToString("c"));

            PermanentEmployee emp2 = new PermanentEmployee("Chris", 45, 25, 0.1m);
            Console.WriteLine(emp2);
            Console.WriteLine("Pay amount: " + emp2.CalculatePay().ToString("c"));

            // assign derived class object to base class variable
            Employee emp3 = emp2;
            Console.WriteLine(emp3);
            Console.WriteLine("Pay amount: " + emp3.CalculatePay().ToString("c"));

            Console.WriteLine("\n PUTTING EMPLOYEES ON ONE PAYROLL LIST: ");
            List<Employee> payroll = new List<Employee>();
            payroll.Add(emp);
            payroll.Add(emp1);
            payroll.Add(emp2);
            //payroll.Add(emp3);

            //
            foreach(Employee empl in payroll)
            {
                Console.WriteLine(empl);
                Console.WriteLine("Pay amount: " + empl.CalculatePay().ToString("c"));
                // the method called is defined the type of the object - !!!! POLYMORPHISM !!!!
            }

            Console.WriteLine("Press any key to Exit.");
            Console.ReadKey();
        }
    }
}
