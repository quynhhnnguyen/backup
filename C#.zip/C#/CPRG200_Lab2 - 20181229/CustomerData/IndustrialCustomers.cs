﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerData
{
    [Serializable]
    public class IndustrialCustomers 
    {
        private List<IndustrialCustomer> customers = new List<IndustrialCustomer>();
 
        public List<IndustrialCustomer> Customers
        {
            get { return customers; }
            set { this.customers = value; }
        }

        public string[] getTotalNumbers()
        {
            decimal totalOfCharge = 0;
            string[] rCustomers = { "Industrial", customers.Count.ToString(), totalOfCharge.ToString() };

            foreach (IndustrialCustomer cust in customers)
            {
                totalOfCharge += cust.ChargeAmount;
            }
            rCustomers[2] = totalOfCharge.ToString();
            return rCustomers;
        }

        public ArrayList getCustomersInfo()
        {
            ArrayList result = new ArrayList();
            foreach (IndustrialCustomer cust in customers)
            {
                result.Add(cust.ToArrayOfValues().ToArray());
            }
            return result;
        }
    }
}
