﻿namespace Queenie_QuynhNguyen_CPRG200_Lab1
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblPageCaption = new System.Windows.Forms.Label();
            this.lblPowerUsed = new System.Windows.Forms.Label();
            this.txtPowerUsed = new System.Windows.Forms.TextBox();
            this.lblCustomerType = new System.Windows.Forms.Label();
            this.cbbCustomerType = new System.Windows.Forms.ComboBox();
            this.lblEstimatedCharge = new System.Windows.Forms.Label();
            this.txtEstimatedCharge = new System.Windows.Forms.TextBox();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpBoxPeakHour = new System.Windows.Forms.GroupBox();
            this.txtOffPeakHours = new System.Windows.Forms.TextBox();
            this.lblOffPeakHours = new System.Windows.Forms.Label();
            this.grpBInfo = new System.Windows.Forms.GroupBox();
            this.txtOffPeakInfo = new System.Windows.Forms.TextBox();
            this.txtPowerUsedInfo = new System.Windows.Forms.TextBox();
            this.lblOffPeakInfo = new System.Windows.Forms.Label();
            this.lblPowerUsedInfo = new System.Windows.Forms.Label();
            this.grpBoxPeakHour.SuspendLayout();
            this.grpBInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPageCaption
            // 
            this.lblPageCaption.AutoSize = true;
            this.lblPageCaption.Font = new System.Drawing.Font("Monotype Corsiva", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPageCaption.Location = new System.Drawing.Point(164, 45);
            this.lblPageCaption.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPageCaption.Name = "lblPageCaption";
            this.lblPageCaption.Size = new System.Drawing.Size(437, 57);
            this.lblPageCaption.TabIndex = 0;
            this.lblPageCaption.Text = "Power Bill Calculation";
            // 
            // lblPowerUsed
            // 
            this.lblPowerUsed.AutoSize = true;
            this.lblPowerUsed.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPowerUsed.Location = new System.Drawing.Point(129, 163);
            this.lblPowerUsed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPowerUsed.Name = "lblPowerUsed";
            this.lblPowerUsed.Size = new System.Drawing.Size(162, 20);
            this.lblPowerUsed.TabIndex = 1;
            this.lblPowerUsed.Text = "Power Used (kWh):";
            // 
            // txtPowerUsed
            // 
            this.txtPowerUsed.Location = new System.Drawing.Point(344, 163);
            this.txtPowerUsed.Name = "txtPowerUsed";
            this.txtPowerUsed.Size = new System.Drawing.Size(212, 24);
            this.txtPowerUsed.TabIndex = 2;
            // 
            // lblCustomerType
            // 
            this.lblCustomerType.AutoSize = true;
            this.lblCustomerType.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCustomerType.Location = new System.Drawing.Point(156, 202);
            this.lblCustomerType.Name = "lblCustomerType";
            this.lblCustomerType.Size = new System.Drawing.Size(134, 20);
            this.lblCustomerType.TabIndex = 8;
            this.lblCustomerType.Text = "Customer Type:";
            // 
            // cbbCustomerType
            // 
            this.cbbCustomerType.DisplayMember = "0,1,2";
            this.cbbCustomerType.FormattingEnabled = true;
            this.cbbCustomerType.Items.AddRange(new object[] {
            "Residential",
            "Commercial",
            "Industrial"});
            this.cbbCustomerType.Location = new System.Drawing.Point(345, 198);
            this.cbbCustomerType.Name = "cbbCustomerType";
            this.cbbCustomerType.Size = new System.Drawing.Size(210, 26);
            this.cbbCustomerType.TabIndex = 9;
            this.cbbCustomerType.ValueMember = "0,1,2";
            this.cbbCustomerType.SelectedIndexChanged += new System.EventHandler(this.cbbCustomerType_SelectedIndexChanged);
            // 
            // lblEstimatedCharge
            // 
            this.lblEstimatedCharge.AutoSize = true;
            this.lblEstimatedCharge.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblEstimatedCharge.Location = new System.Drawing.Point(61, 34);
            this.lblEstimatedCharge.Name = "lblEstimatedCharge";
            this.lblEstimatedCharge.Size = new System.Drawing.Size(125, 15);
            this.lblEstimatedCharge.TabIndex = 10;
            this.lblEstimatedCharge.Text = "Estimated Charge:";
            // 
            // txtEstimatedCharge
            // 
            this.txtEstimatedCharge.Enabled = false;
            this.txtEstimatedCharge.Location = new System.Drawing.Point(192, 28);
            this.txtEstimatedCharge.Name = "txtEstimatedCharge";
            this.txtEstimatedCharge.ReadOnly = true;
            this.txtEstimatedCharge.Size = new System.Drawing.Size(117, 24);
            this.txtEstimatedCharge.TabIndex = 11;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(343, 296);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(96, 24);
            this.btnCalculate.TabIndex = 12;
            this.btnCalculate.Text = "&Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(445, 296);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(80, 24);
            this.btnReset.TabIndex = 13;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(534, 296);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(76, 24);
            this.btnExit.TabIndex = 14;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // grpBoxPeakHour
            // 
            this.grpBoxPeakHour.Controls.Add(this.txtOffPeakHours);
            this.grpBoxPeakHour.Controls.Add(this.lblOffPeakHours);
            this.grpBoxPeakHour.Location = new System.Drawing.Point(85, 229);
            this.grpBoxPeakHour.Name = "grpBoxPeakHour";
            this.grpBoxPeakHour.Size = new System.Drawing.Size(524, 45);
            this.grpBoxPeakHour.TabIndex = 15;
            this.grpBoxPeakHour.TabStop = false;
            this.grpBoxPeakHour.Visible = false;
            // 
            // txtOffPeakHours
            // 
            this.txtOffPeakHours.Location = new System.Drawing.Point(260, 11);
            this.txtOffPeakHours.Name = "txtOffPeakHours";
            this.txtOffPeakHours.Size = new System.Drawing.Size(212, 24);
            this.txtOffPeakHours.TabIndex = 16;
            // 
            // lblOffPeakHours
            // 
            this.lblOffPeakHours.AutoSize = true;
            this.lblOffPeakHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOffPeakHours.Location = new System.Drawing.Point(4, 13);
            this.lblOffPeakHours.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOffPeakHours.Name = "lblOffPeakHours";
            this.lblOffPeakHours.Size = new System.Drawing.Size(227, 20);
            this.lblOffPeakHours.TabIndex = 4;
            this.lblOffPeakHours.Text = "Off Peak Hour Used (kWh):";
            // 
            // grpBInfo
            // 
            this.grpBInfo.Controls.Add(this.txtOffPeakInfo);
            this.grpBInfo.Controls.Add(this.txtPowerUsedInfo);
            this.grpBInfo.Controls.Add(this.lblOffPeakInfo);
            this.grpBInfo.Controls.Add(this.lblPowerUsedInfo);
            this.grpBInfo.Controls.Add(this.lblEstimatedCharge);
            this.grpBInfo.Controls.Add(this.txtEstimatedCharge);
            this.grpBInfo.Location = new System.Drawing.Point(678, 121);
            this.grpBInfo.Name = "grpBInfo";
            this.grpBInfo.Size = new System.Drawing.Size(328, 188);
            this.grpBInfo.TabIndex = 16;
            this.grpBInfo.TabStop = false;
            this.grpBInfo.Text = "Estimated  Power Bill Without GST:";
            this.grpBInfo.Visible = false;
            // 
            // txtOffPeakInfo
            // 
            this.txtOffPeakInfo.Enabled = false;
            this.txtOffPeakInfo.Location = new System.Drawing.Point(192, 89);
            this.txtOffPeakInfo.Name = "txtOffPeakInfo";
            this.txtOffPeakInfo.Size = new System.Drawing.Size(117, 24);
            this.txtOffPeakInfo.TabIndex = 17;
            this.txtOffPeakInfo.Visible = false;
            // 
            // txtPowerUsedInfo
            // 
            this.txtPowerUsedInfo.Enabled = false;
            this.txtPowerUsedInfo.Location = new System.Drawing.Point(192, 60);
            this.txtPowerUsedInfo.Name = "txtPowerUsedInfo";
            this.txtPowerUsedInfo.Size = new System.Drawing.Size(117, 24);
            this.txtPowerUsedInfo.TabIndex = 17;
            // 
            // lblOffPeakInfo
            // 
            this.lblOffPeakInfo.AutoSize = true;
            this.lblOffPeakInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOffPeakInfo.Location = new System.Drawing.Point(7, 95);
            this.lblOffPeakInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblOffPeakInfo.Name = "lblOffPeakInfo";
            this.lblOffPeakInfo.Size = new System.Drawing.Size(178, 15);
            this.lblOffPeakInfo.TabIndex = 12;
            this.lblOffPeakInfo.Text = "Off Peak Hour Used (kWh):";
            this.lblOffPeakInfo.Visible = false;
            // 
            // lblPowerUsedInfo
            // 
            this.lblPowerUsedInfo.AutoSize = true;
            this.lblPowerUsedInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPowerUsedInfo.Location = new System.Drawing.Point(41, 66);
            this.lblPowerUsedInfo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPowerUsedInfo.Name = "lblPowerUsedInfo";
            this.lblPowerUsedInfo.Size = new System.Drawing.Size(129, 15);
            this.lblPowerUsedInfo.TabIndex = 11;
            this.lblPowerUsedInfo.Text = "Power Used (kWh):";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1018, 430);
            this.Controls.Add(this.grpBInfo);
            this.Controls.Add(this.grpBoxPeakHour);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.cbbCustomerType);
            this.Controls.Add(this.lblCustomerType);
            this.Controls.Add(this.txtPowerUsed);
            this.Controls.Add(this.lblPowerUsed);
            this.Controls.Add(this.lblPageCaption);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmMain";
            this.Text = "Power Bill Calculation";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.grpBoxPeakHour.ResumeLayout(false);
            this.grpBoxPeakHour.PerformLayout();
            this.grpBInfo.ResumeLayout(false);
            this.grpBInfo.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblPageCaption;
        private System.Windows.Forms.Label lblPowerUsed;
        private System.Windows.Forms.TextBox txtPowerUsed;
        private System.Windows.Forms.Label lblCustomerType;
        private System.Windows.Forms.ComboBox cbbCustomerType;
        private System.Windows.Forms.Label lblEstimatedCharge;
        private System.Windows.Forms.TextBox txtEstimatedCharge;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.GroupBox grpBoxPeakHour;
        private System.Windows.Forms.TextBox txtOffPeakHours;
        private System.Windows.Forms.Label lblOffPeakHours;
        private System.Windows.Forms.GroupBox grpBInfo;
        private System.Windows.Forms.TextBox txtPowerUsedInfo;
        private System.Windows.Forms.Label lblOffPeakInfo;
        private System.Windows.Forms.Label lblPowerUsedInfo;
        private System.Windows.Forms.TextBox txtOffPeakInfo;
    }
}

