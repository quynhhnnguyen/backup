﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerData
{
    /* This is a Customers Object which is used to serialize and deserialize customer data to file or from file.
       Author: Quynh Nguyen (Queenie)
       Date: Dec - 23 - 2018
     */
    [Serializable]
    public class Customers
    {
        // list of customer data for each customer type
        private List<ResidentialCustomer> residentialCustomers = new List<ResidentialCustomer>();
        private List<CommercialCustomer> commercialCustomers = new List<CommercialCustomer>();
        private List<IndustrialCustomer> industrialCustomers = new List<IndustrialCustomer>();

        //contruction
        public Customers() { }

        // Get Set methods
        public List<ResidentialCustomer> ResidentialCustomers
        {
            get { return residentialCustomers; }
            set { this.residentialCustomers = value; }
        }

        public List<CommercialCustomer> CommercialCustomers
        {
            get { return commercialCustomers; }
            set { this.commercialCustomers = value; }
        }

        public List<IndustrialCustomer> IndustrialCustomers
        {
            get { return industrialCustomers; }
            set { this.industrialCustomers = value; }
        }

        // get list of customer data by customer type
        public ArrayList getCustomersInfo(char custType)
        {
            ArrayList result = new ArrayList();

            if(custType.Equals((char)Utils.CustomerTypeEnum.Residential))
                foreach (ResidentialCustomer cust in residentialCustomers)
                {
                    result.Add(cust.ToArrayOfValues().ToArray());
                }

            if (custType.Equals((char)Utils.CustomerTypeEnum.Commercial))
                foreach (CommercialCustomer cust in commercialCustomers)
                {
                    result.Add(cust.ToArrayOfValues().ToArray());
                }

            if (custType.Equals((char)Utils.CustomerTypeEnum.Industrial))
                foreach (IndustrialCustomer cust in industrialCustomers)
                {
                    result.Add(cust.ToArrayOfValues().ToArray());
                }

            return result;
        }

        // calculate list of customer data by customer type
        public string[] getTotalNumbers(char custType)
        {
            decimal totalOfCharge = 0; // total charge for each customer type
            string[] rCustomers = { Utils.CustomerTypeNames['R'], residentialCustomers.Count.ToString(), totalOfCharge.ToString() };
            string[] cCustomers = { Utils.CustomerTypeNames['C'], commercialCustomers.Count.ToString(), totalOfCharge.ToString() };
            string[] iCustomers = { Utils.CustomerTypeNames['I'], industrialCustomers.Count.ToString(), totalOfCharge.ToString() };
            string[] result = rCustomers;

            if (custType.Equals((char)Utils.CustomerTypeEnum.Residential))
            {
                foreach (ResidentialCustomer cust in residentialCustomers)
                {
                    totalOfCharge += cust.ChargeAmount;
                }
                rCustomers[2] = totalOfCharge.ToString();
                result = rCustomers;
            }

            if (custType.Equals((char)Utils.CustomerTypeEnum.Commercial))
            {
                foreach (CommercialCustomer cust in commercialCustomers)
                {
                    totalOfCharge += cust.ChargeAmount;
                }
                cCustomers[2] = totalOfCharge.ToString();
                result = cCustomers;
            }

            if (custType.Equals((char)Utils.CustomerTypeEnum.Industrial))
            { 
                foreach (IndustrialCustomer cust in industrialCustomers)
                {
                    totalOfCharge += cust.ChargeAmount;
                }
                iCustomers[2] = totalOfCharge.ToString();
                result = iCustomers;
            }
            
            return result;
        }

    }
}
