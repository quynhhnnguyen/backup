﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ex1
{
    public static class DBUtilities
    {
        private static NorthwindDataContext context = new NorthwindDataContext();

        public static List<string> GetCustomerIds()
        {
            List<string> customerIds = (from cust in context.Customers
                                        select cust.CustomerID).ToList();

            return customerIds;
        }

        public static List<Order> GetOrdersByCustomerId(string custID)
        {
            List<Order> orders = (from order in context.Orders
                                  where order.CustomerID == custID
                                  select order).ToList();

            return orders;
        }

        public static Customer GetCustomer(string custID)
        {
            Customer customer = (from cust in context.Customers
                                 where cust.CustomerID == custID
                                 select cust).Single();

            return customer;
        }

    }
}
