﻿namespace Ex_Day1
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCaption = new System.Windows.Forms.Label();
            this.lblWorkedHours = new System.Windows.Forms.Label();
            this.lblHourlyRate = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.txtWorkedHours = new System.Windows.Forms.TextBox();
            this.txtHourlyRate = new System.Windows.Forms.TextBox();
            this.txtRegularPay = new System.Windows.Forms.TextBox();
            this.txtOverTimePay = new System.Windows.Forms.TextBox();
            this.txtTotalPay = new System.Windows.Forms.TextBox();
            this.grpBRegPay = new System.Windows.Forms.GroupBox();
            this.grpBTotalPay = new System.Windows.Forms.GroupBox();
            this.grpBOTPay = new System.Windows.Forms.GroupBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.grpBRegPay.SuspendLayout();
            this.grpBTotalPay.SuspendLayout();
            this.grpBOTPay.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCaption
            // 
            this.lblCaption.AutoSize = true;
            this.lblCaption.Font = new System.Drawing.Font("Monotype Corsiva", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCaption.Location = new System.Drawing.Point(228, 27);
            this.lblCaption.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCaption.Name = "lblCaption";
            this.lblCaption.Size = new System.Drawing.Size(335, 57);
            this.lblCaption.TabIndex = 0;
            this.lblCaption.Text = "Salary Calculator";
            // 
            // lblWorkedHours
            // 
            this.lblWorkedHours.AutoSize = true;
            this.lblWorkedHours.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWorkedHours.Location = new System.Drawing.Point(122, 141);
            this.lblWorkedHours.Name = "lblWorkedHours";
            this.lblWorkedHours.Size = new System.Drawing.Size(123, 20);
            this.lblWorkedHours.TabIndex = 1;
            this.lblWorkedHours.Text = "Worked Hours";
            // 
            // lblHourlyRate
            // 
            this.lblHourlyRate.AutoSize = true;
            this.lblHourlyRate.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHourlyRate.Location = new System.Drawing.Point(278, 141);
            this.lblHourlyRate.Name = "lblHourlyRate";
            this.lblHourlyRate.Size = new System.Drawing.Size(104, 20);
            this.lblHourlyRate.TabIndex = 2;
            this.lblHourlyRate.Text = "Hourly Rate";
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(433, 172);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(105, 30);
            this.btnCalculate.TabIndex = 3;
            this.btnCalculate.Text = "&Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // txtWorkedHours
            // 
            this.txtWorkedHours.Location = new System.Drawing.Point(127, 174);
            this.txtWorkedHours.Name = "txtWorkedHours";
            this.txtWorkedHours.Size = new System.Drawing.Size(117, 26);
            this.txtWorkedHours.TabIndex = 4;
            // 
            // txtHourlyRate
            // 
            this.txtHourlyRate.Location = new System.Drawing.Point(282, 174);
            this.txtHourlyRate.Name = "txtHourlyRate";
            this.txtHourlyRate.Size = new System.Drawing.Size(117, 26);
            this.txtHourlyRate.TabIndex = 5;
            // 
            // txtRegularPay
            // 
            this.txtRegularPay.Location = new System.Drawing.Point(6, 25);
            this.txtRegularPay.Name = "txtRegularPay";
            this.txtRegularPay.Size = new System.Drawing.Size(117, 26);
            this.txtRegularPay.TabIndex = 6;
            // 
            // txtOverTimePay
            // 
            this.txtOverTimePay.Location = new System.Drawing.Point(6, 25);
            this.txtOverTimePay.Name = "txtOverTimePay";
            this.txtOverTimePay.Size = new System.Drawing.Size(117, 26);
            this.txtOverTimePay.TabIndex = 7;
            // 
            // txtTotalPay
            // 
            this.txtTotalPay.Location = new System.Drawing.Point(10, 25);
            this.txtTotalPay.Name = "txtTotalPay";
            this.txtTotalPay.Size = new System.Drawing.Size(117, 26);
            this.txtTotalPay.TabIndex = 8;
            // 
            // grpBRegPay
            // 
            this.grpBRegPay.Controls.Add(this.txtRegularPay);
            this.grpBRegPay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBRegPay.Location = new System.Drawing.Point(123, 219);
            this.grpBRegPay.Name = "grpBRegPay";
            this.grpBRegPay.Size = new System.Drawing.Size(133, 63);
            this.grpBRegPay.TabIndex = 12;
            this.grpBRegPay.TabStop = false;
            this.grpBRegPay.Text = "Regular Pay";
            this.grpBRegPay.Visible = false;
            // 
            // grpBTotalPay
            // 
            this.grpBTotalPay.Controls.Add(this.txtTotalPay);
            this.grpBTotalPay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBTotalPay.Location = new System.Drawing.Point(424, 219);
            this.grpBTotalPay.Name = "grpBTotalPay";
            this.grpBTotalPay.Size = new System.Drawing.Size(133, 63);
            this.grpBTotalPay.TabIndex = 13;
            this.grpBTotalPay.TabStop = false;
            this.grpBTotalPay.Text = "Total Pay";
            this.grpBTotalPay.Visible = false;
            // 
            // grpBOTPay
            // 
            this.grpBOTPay.Controls.Add(this.txtOverTimePay);
            this.grpBOTPay.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpBOTPay.Location = new System.Drawing.Point(276, 219);
            this.grpBOTPay.Name = "grpBOTPay";
            this.grpBOTPay.Size = new System.Drawing.Size(133, 63);
            this.grpBOTPay.TabIndex = 14;
            this.grpBOTPay.TabStop = false;
            this.grpBOTPay.Text = "Overtime Pay";
            this.grpBOTPay.Visible = false;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(544, 172);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(69, 30);
            this.btnReset.TabIndex = 15;
            this.btnReset.Text = "&Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(619, 172);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(56, 30);
            this.btnExit.TabIndex = 16;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(777, 336);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.grpBOTPay);
            this.Controls.Add(this.grpBTotalPay);
            this.Controls.Add(this.grpBRegPay);
            this.Controls.Add(this.txtHourlyRate);
            this.Controls.Add(this.txtWorkedHours);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.lblHourlyRate);
            this.Controls.Add(this.lblWorkedHours);
            this.Controls.Add(this.lblCaption);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmMain";
            this.Text = "Salary Calculator";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.grpBRegPay.ResumeLayout(false);
            this.grpBRegPay.PerformLayout();
            this.grpBTotalPay.ResumeLayout(false);
            this.grpBTotalPay.PerformLayout();
            this.grpBOTPay.ResumeLayout(false);
            this.grpBOTPay.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblCaption;
        private System.Windows.Forms.Label lblWorkedHours;
        private System.Windows.Forms.Label lblHourlyRate;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.TextBox txtWorkedHours;
        private System.Windows.Forms.TextBox txtHourlyRate;
        private System.Windows.Forms.TextBox txtRegularPay;
        private System.Windows.Forms.TextBox txtOverTimePay;
        private System.Windows.Forms.TextBox txtTotalPay;
        private System.Windows.Forms.GroupBox grpBRegPay;
        private System.Windows.Forms.GroupBox grpBTotalPay;
        private System.Windows.Forms.GroupBox grpBOTPay;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Button btnExit;
    }
}

