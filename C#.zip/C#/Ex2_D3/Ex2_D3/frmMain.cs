﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ex2_D3
{
    public partial class frmMain : Form
    {
        int[,] tShirtInfo = { { 345, 564, 1245, 1690 }, { 1232, 1534, 795, 238 }, { 1189, 1387, 987, 546 } };
            //new int[3, 4];
        string[] colors = { "Black", "White", "Red" };


        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            string[] row1 = { "Black", "345", "564", "1245", "1690" };
            string[] row2 = { "White", "1232", "1534", "795", "238" };
            string[] row3 = { "Red", "1189", "1387", "987", "546" };
            dGVInfo.Rows.Add(row1);
            dGVInfo.Rows.Add(row2);
            dGVInfo.Rows.Add(row3);
        }

        private void btnFindWinner_Click(object sender, EventArgs e)
        {


            int winnerNum = 0;
            int winnerSum = 0;
            for (int i = 0; i < tShirtInfo.GetLength(0); i++) //rows
            {
                int sum = 0;
                for (int j = 0; j < tShirtInfo.GetLength(1); j++) //columns
                {
                    sum += tShirtInfo[i, j];
                }

                if(sum > winnerSum)
                {
                    winnerSum = sum;
                    winnerNum = i;
                }

                txtWinner.Text = colors[winnerNum];
                txtTotal.Text = winnerSum.ToString();
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
