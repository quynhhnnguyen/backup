﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaxCalculator
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal salary = Convert.ToDecimal(txtSalary.Text);
            decimal excessTax = 0.0m;
            decimal baseTax = 0.0m;
            decimal excessPercent = 0m;


            if (salary <= 14999.99m)
            {
                excessPercent = .15m;
                baseTax = 0.0m;
                
            } else if(15000 >= salary && salary <= 29999.99m)
            {
                baseTax = 2250m;
                excessPercent = .18m;
            } else if(30000 >= salary && salary <= 49999.99m)
            {
                baseTax = 4950m;
                excessPercent = .22m;
            } else if(50000 >= salary && salary <= 79999.99m)
            {
                baseTax = 9350m;
                excessPercent = .27m;
            } else
            {
                baseTax = 17850m;
                excessPercent = .33m;
            }

            txtBaseTax.Text = baseTax.ToString("c");
            txtExcessTax.Text = (salary * excessPercent).ToString("c");
            txtTotalTax.Text = (baseTax + (salary * excessPercent)).ToString("c");
        }
    }

}
