﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlayCards
{
    class Card
    {
        private string rank;
        private string suit;

        public Card(string rank = "", string suit = "")
        {
            this.rank = rank;
            this.suit = suit;
        }

        public override string ToString()
        {
            char[] suitChar = { '\u2663', '\u2666', '\u2665', '\u2660'};
            char[] rankChar = { 'A', '2', '3', '4', '5', '6', '7', '8', '9', '1', 'J', 'Q', 'K'};
            return this.rank + " " + this.suit;
        }
    }
}
