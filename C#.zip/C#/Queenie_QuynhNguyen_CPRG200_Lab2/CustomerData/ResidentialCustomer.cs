﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerData
{
    /* This is a Residential Customer Object.
       Author: Quynh Nguyen (Queenie)
       Date: Dec - 23 - 2018
     */
    [Serializable]
    public class ResidentialCustomer : Customer 
    {
        // construction
        public ResidentialCustomer() : base(-1, "", 'R', 0)
        {

        }

        // construction
        public ResidentialCustomer(Int32 accountNo = -1, string customerName = "",
                        char customerType = 'R', decimal chargeAmount = 0) :
            base(accountNo, customerName, customerType, chargeAmount)
        {
            //no need to implement
        }

        // calculate bill for Residential Customer
        public override decimal CalculateCharge(decimal kwhPowerUsed, decimal kwhOffPeakPowerUsed = 0)
        {
            if (kwhPowerUsed >= 0)
            {
                this.ChargeAmount = Utils.CalculateBillForResidential(kwhPowerUsed);
            }
            return this.ChargeAmount;
        }

        // generate array of customer data
        public override List<string> ToArrayOfValues()
        {
            List<string> result = new List<string>();
            result.Add(this.AccountNo.ToString());
            result.Add(this.CustomerName);
            result.Add("Residential");
            result.Add(this.ChargeAmount.ToString());
            return result;
        }
    }
}
