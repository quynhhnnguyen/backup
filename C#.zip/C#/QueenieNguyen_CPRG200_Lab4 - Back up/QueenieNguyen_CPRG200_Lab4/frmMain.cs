﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QueenieNguyen_CPRG200_Lab4
{
    /* This Application Allows User view Order information and update the shipped date
     * Author: Queenie Nguyen
     * Created Date: Jan - 11 - 2019
     */
    public partial class frmMain : Form
    {
        //variable declaration
        Order order = null;

        public frmMain()
        {
            InitializeComponent();
        }

        // form load handling
        private void frmMain_Load(object sender, EventArgs e)
        {
            try
            {
                // load order Id list
                orderIDComboBox.DataSource = OrderDB.GetOrderIDs();
            }
            catch(Exception ex)
            {
                // Error handling
                MessageBox.Show("Error happens: " + ex.Message, ex.GetType().ToString());
            }
        }

        // order Id change handling
        private void orderIDComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int orderId = Convert.ToInt32(orderIDComboBox.SelectedValue);
                List<Order_Detail> orderDetails = OrderDetailDB.GetOrderDetails(orderId); // get order details
                order_DetailDataGridView.DataSource = orderDetails;
                txtOrderTotal.Text = Utils.CalculateOrderTotal(orderDetails).ToString("c"); // calculate order total
                DisplayOrder(orderId);
            }
            catch(Exception ex)
            {
                //Error Handling
                MessageBox.Show("Error happens: " + ex.Message, ex.GetType().ToString());
            }
            
        }

        // display order information
        private void DisplayOrder(int orderId)
        { 
            order = OrderDB.GetOrder(orderId);
            customerIDTextBox.Text = Utils.ConvertToString(order.CustomerID);
            employeeIDTextBox.Text = Utils.ConvertToString(order.EmployeeID);
            freightTextBox.Text = Utils.ConvertToString(order.Freight);
            orderDateDateTimePicker.Value = Utils.ConvertToDateTime(order.OrderDate);
            requiredDateDateTimePicker.Value = Utils.ConvertToDateTime(order.RequiredDate);
            shipAddressTextBox.Text = Utils.ConvertToString(order.ShipAddress);
            shipCityTextBox.Text = Utils.ConvertToString(order.ShipCity);
            shipCountryTextBox.Text = Utils.ConvertToString(order.ShipCountry);
            shipNameTextBox.Text = Utils.ConvertToString(order.ShipName);
            shippedDateDateTimePicker.Value = Utils.ConvertToDateTime(order.ShippedDate);
            shipPostalCodeTextBox.Text = Utils.ConvertToString(order.ShipPostalCode);
            shipRegionTextBox.Text = Utils.ConvertToString(order.ShipRegion);
            shipViaTextBox.Text = Utils.ConvertToString(order.ShipVia);
        }

        // save shipped date to database
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (orderDateDateTimePicker.Value.CompareTo(shippedDateDateTimePicker.Value) > 0 ||
                requiredDateDateTimePicker.Value.CompareTo(shippedDateDateTimePicker.Value) < 0)
                {
                    MessageBox.Show("Shipped Date could not be ealier than Order Date nor later than Required Date.");
                }
                else
                    OrderDB.UpdateShippedDate(order.OrderID, shippedDateDateTimePicker.Value);
            }
            catch (Exception ex)
            {
                //Error Handling
                MessageBox.Show("Error happens: " + ex.Message, ex.GetType().ToString());
            }
            
        }

        // validate shipped date
        private void shippedDateDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            if(orderDateDateTimePicker.Value.CompareTo(shippedDateDateTimePicker.Value)>0 ||
                requiredDateDateTimePicker.Value.CompareTo(shippedDateDateTimePicker.Value)<0)
            {
                MessageBox.Show("Shipped Date could not be ealier than Order Date nor later than Required Date.");
            }
        }
    }
}
