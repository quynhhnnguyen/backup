﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using CustomerData;


namespace Queenie_QuynhNguyen_CPRG200_Lab2
{
    public static class Utils
    {
        public enum CustomerTypeEnum { Residential = 'R', Commercial = 'C', Industrial = 'I'}; // Customer Types
        // Customer Type Names
        public static IDictionary<Char, String> CustomerTypeNames = new Dictionary<char, string>()
        {
            { 'R', "Residential" } , { 'C', "Commercial" }, { 'I', "Industrial" }
        };
        public static string customerFilePath = "customers.txt";
        public static int MAX_CUSTOMERS = 500;

        // calculate bill for Residential Customer
        public static decimal CalculateBillForResidential(decimal kWhUsed)
        {
            // 6.00 - default price, 0.052 - unit price
            return 6.00m + 0.052m * kWhUsed;
        }

        // calculate bill for Industrial Customer
        public static decimal CalculateBillForIndustrial(decimal kWhPeekHourUsed, decimal kWhOffPeakHourUsed)
        {
            decimal result = 76; // default price even though kWhPeekHourUsed is zero

            // calculate charge for peak hour power used
            if (kWhPeekHourUsed > 1000)
            {
                result += (kWhPeekHourUsed - 1000m) * 0.065m;
            }

            // calculate charge for off-peak hour power used
            result += 40; // default price even though kWhOffPeakHourUsed is zero

            // different unit price is applied when power used is over 1000
            if (kWhOffPeakHourUsed > 1000)
            {
                result += (kWhOffPeakHourUsed - 1000m) * 0.028m;
            }

            return result;
        }

        // calculate bill for Commercial Customer
        public static decimal CalculateBillForCommercial(decimal kWhUsed)
        {
            decimal result = 60; // default value, even though power used is zero

            // different unit price is applied when power used is over 1000
            if (kWhUsed > 1000)
            {
                result += (kWhUsed - 1000m) * 0.045m;
            }

            return result;
        }

        public static void WriteData(Customers custList)
        {
            FileStream fs = null;
            ICollection objects = new BaseCollection();

            try
            {
                /*Customers Emps = new Customers();
                // Note that only the collection is serialized -- not the   
                // CollectionName or any other public property of the class.  
                Emps.CollectionName = "Customers";
                ResidentialCustomer John100 = new ResidentialCustomer(12, "John");
                Emps.Add(John100);*/

                //open the file for writing  and overwrite old content.
                TextWriter writer = new StreamWriter(customerFilePath);

                /*XmlSerializer serializer = new XmlSerializer(typeof(List<ResidentialCustomer>));
                if(custList.ResidentialCustomers.Customers.Count > 0)
                    serializer.Serialize(writer, custList.ResidentialCustomers.Customers);

                serializer = new XmlSerializer(typeof(List<CommercialCustomer>));
                if (custList.CommercialCustomers.Customers.Count > 0)
                    serializer.Serialize(writer, custList.CommercialCustomers.Customers);

                serializer = new XmlSerializer(typeof(List<IndustrialCustomer>));
                if (custList.IndustrialCustomers.Customers.Count > 0)
                    serializer.Serialize(writer, custList.IndustrialCustomers.Customers);*/

                XmlSerializer serializer = new XmlSerializer(typeof(Customers));
                serializer.Serialize(writer, custList);


            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while writing to the file: " +
                    ex.Message, ex.GetType().ToString());

            }
            finally
            {
                //if (sw != null) sw.Close(); // also close fs
                if (fs != null) fs.Close();
            }
        }

        public static Customers LoadCustomersFromFile()
        {
            //List<Customer> custList = new List<Customer>();
            Customers custList = new Customers();
            if (File.Exists(Utils.customerFilePath))
            {
                /*XmlDocument doc = new XmlDocument();
                doc.Load(Utils.customerFilePath);
                XmlSerializer serializer = new XmlSerializer(typeof(Customer));
                for (int i = 0; i < doc.ChildNodes.Count; i++)
                {
                    custList.Add((Customer)serializer.Deserialize(new StreamReader(doc.ChildNodes.Item(i).InnerXml)));
                }*/
                XmlSerializer reader = new XmlSerializer(typeof(Customers));
                StreamReader file = new StreamReader( Utils.customerFilePath);
                custList = (Customers)reader.Deserialize(file);
                file.Close();
            }
            return custList;
        }
    }
}
