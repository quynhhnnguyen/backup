﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerData
{
    [Serializable]
    public class Customers
    {
        /*private ResidentialCustomers residentialCustomers = new ResidentialCustomers();
        private CommercialCustomers commercialCustomers = new CommercialCustomers();
        private IndustrialCustomers industrialCustomers = new IndustrialCustomers();
 
        public Customers() { }

        public ResidentialCustomers ResidentialCustomers
        {
            get { return residentialCustomers; }
            set { this.residentialCustomers = value; }
        }

        public CommercialCustomers CommercialCustomers
        {
            get { return commercialCustomers; }
            set { this.commercialCustomers = value; }
        }

        public IndustrialCustomers IndustrialCustomers
        {
            get { return industrialCustomers; }
            set { this.industrialCustomers = value; }
        }*/

        private List<ResidentialCustomer> residentialCustomers = new List<ResidentialCustomer>();
        private List<CommercialCustomer> commercialCustomers = new List<CommercialCustomer>();
        private List<IndustrialCustomer> industrialCustomers = new List<IndustrialCustomer>();

        public Customers() { }

        public List<ResidentialCustomer> ResidentialCustomers
        {
            get { return residentialCustomers; }
            set { this.residentialCustomers = value; }
        }

        public List<CommercialCustomer> CommercialCustomers
        {
            get { return commercialCustomers; }
            set { this.commercialCustomers = value; }
        }

        public List<IndustrialCustomer> IndustrialCustomers
        {
            get { return industrialCustomers; }
            set { this.industrialCustomers = value; }
        }

        public ArrayList getCustomersInfo(string custType)
        {
            ArrayList result = new ArrayList();

            if(custType.Equals("R"))
                foreach (ResidentialCustomer cust in residentialCustomers)
                {
                    result.Add(cust.ToArrayOfValues().ToArray());
                }

            if (custType.Equals("C"))
                foreach (CommercialCustomer cust in commercialCustomers)
                {
                    result.Add(cust.ToArrayOfValues().ToArray());
                }

            if (custType.Equals("I"))
                foreach (IndustrialCustomer cust in industrialCustomers)
                {
                    result.Add(cust.ToArrayOfValues().ToArray());
                }

            return result;
        }

        public string[] getTotalNumbers(string custType)
        {
            decimal totalOfCharge = 0;
            string[] rCustomers = { "Residential", residentialCustomers.Count.ToString(), totalOfCharge.ToString() };
            string[] cCustomers = { "Commercial", commercialCustomers.Count.ToString(), totalOfCharge.ToString() };
            string[] iCustomers = { "Industrial", industrialCustomers.Count.ToString(), totalOfCharge.ToString() };
            string[] result = rCustomers;

            if (custType.Equals("R"))
            {
                foreach (ResidentialCustomer cust in residentialCustomers)
                {
                    totalOfCharge += cust.ChargeAmount;
                }
                rCustomers[2] = totalOfCharge.ToString();
                result = rCustomers;
            }

            if (custType.Equals("C"))
            {
                foreach (CommercialCustomer cust in commercialCustomers)
                {
                    totalOfCharge += cust.ChargeAmount;
                }
                cCustomers[2] = totalOfCharge.ToString();
                result = cCustomers;
            }

            if (custType.Equals("I"))
            { 
                foreach (IndustrialCustomer cust in industrialCustomers)
                {
                    totalOfCharge += cust.ChargeAmount;
                }
                iCustomers[2] = totalOfCharge.ToString();
                result = iCustomers;
            }
            
            return result;
        }

        /*public int Add(Customer cust)
        {
            int result = -1;
            if (cust is ResidentialCustomer)
            {
                this.residentialCustomers.Customers.Add((ResidentialCustomer)cust);
                result = this.residentialCustomers.Customers.Count -1 ;
            }
                
            if (cust is CommercialCustomer)
            {
                this.commercialCustomers.Customers.Add((CommercialCustomer)cust);
                result = this.commercialCustomers.Customers.Count - 1;
            }
                
            if (cust is IndustrialCustomer)
            {
                this.industrialCustomers.Customers.Add((IndustrialCustomer)cust);
                result = this.industrialCustomers.Customers.Count - 1;
            }                

            return result;
        }*/

        /*public Customer this[int index]
        {
            get { return (Customer)customers[index]; }
        }

        public void CopyTo(Array a, int index)
        {
            customers.CopyTo(a, index);
        }
        public int Count
        {
            get { return customers.Count; }
        }
        public object SyncRoot
        {
            get { return this; }
        }
        public bool IsSynchronized
        {
            get { return false; }
        }
        public IEnumerator GetEnumerator()
        {
            return customers.GetEnumerator();
        }

        public void Add(Customer newCustomer)
        {
            customers.Add(newCustomer);
        }*/
    }
}
