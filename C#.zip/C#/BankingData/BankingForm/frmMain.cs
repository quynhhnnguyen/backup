﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BankingData;

namespace BankingForm
{
    public partial class frmMain : Form
    {
        Account account;
        public frmMain()
        {
            InitializeComponent();
        }

        // user deposit money
        private void btnDeposite_Click(object sender, EventArgs e)
        {
            try
            {
                // get the amount
                decimal amount = Convert.ToDecimal(txtAmount.Text);
                decimal oldBalance = account.Balance;
                // call deposite method from accont
                account.Deposit(amount);

                //display feedback
                if (oldBalance == account.Balance)
                {
                    MessageBox.Show("Deposite amount should be positive");
                    txtAmount.SelectAll();
                    txtAmount.Focus();
                }
                else //success
                {
                    txtBalance.Text = account.Balance.ToString("c");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error happened: " + ex.Message, ex.GetType().ToString());
            }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            // create account with $500
            account = new Account(500);

            // display current balance
            txtBalance.Text = account.Balance.ToString("c");
        }

        private void btnWithdraw_Click(object sender, EventArgs e)
        {
            try
            {
                // get the amount
                decimal amount = Convert.ToDecimal(txtAmount.Text);
                decimal oldBalance = account.Balance;
                // call withdraw method from accont
                bool isSuccessful = account.Withdraw(amount);

                //display feedback
                if (!isSuccessful)
                {
                    if (amount <= 0)
                    {
                        MessageBox.Show("Withdrawal amount should be positive");
                    }
                    else
                    {
                        MessageBox.Show("Unsufficient Balance: You cannot withdraw more than your balance - "
                            + account.Balance.ToString("c"));
                    }

                    txtAmount.SelectAll();
                    txtAmount.Focus();
                }
                else //success
                {
                    txtBalance.Text = account.Balance.ToString("c");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error happened: " + ex.Message, ex.GetType().ToString());
            }
            
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
