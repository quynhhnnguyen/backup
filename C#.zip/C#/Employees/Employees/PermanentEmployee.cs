﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
    class PermanentEmployee : Employee
    {
        //added data
        private decimal rrspPct; // RRSP percentage.

        public PermanentEmployee(string name, decimal hours, decimal payRate, decimal r) :
            base(name, hours, payRate) //passes 3 first parameters to base constructor.
        {
            this.rrspPct = r;
        }

        //public methods
        public override string ToString()
        {
            // call method from base class & append additional value.
            return base.ToString() + 
                "\n RRSP deduction: " + rrspPct.ToString("p"); 
        }

        public decimal CalculateRRSP()
        {
            return base.CalculatePay() * rrspPct;
        }

        public override decimal CalculatePay()
        {
            decimal basePay = base.CalculatePay();
            decimal rrspAmount = CalculateRRSP();
            return basePay - rrspAmount;

        }
    }
}
