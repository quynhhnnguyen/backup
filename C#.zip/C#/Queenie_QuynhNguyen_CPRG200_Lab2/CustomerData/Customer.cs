﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerData
{
    /* This is a Customer Abstract class which demostrate a common customer.
       Author: Quynh Nguyen (Queenie)
       Date: Dec - 23 - 2018
     */
    [Serializable]
    public abstract class Customer
    {
        // customer properties
        private int accountNo;
        private string customerName;
        private char customerType;
        private decimal chargeAmount;

        // construction
        public Customer()
        {
            this.accountNo = -1;
            this.customerName = "";
            this.customerType = 'R';
            this.chargeAmount = 0;
        }

        //construction
        public Customer(int accountNo = -1, string customerName = "",
                        char customerType = 'R', decimal chargeAmount = 0)
        {
            this.accountNo = accountNo;
            this.customerName = customerName;
            this.customerType = customerType;
            this.chargeAmount = chargeAmount;
        }

        public string CustomerName
        {
            get { return this.customerName; }
            set
            {   //customer Name should be non-empty string
                if (!String.IsNullOrEmpty(value))
                    this.customerName = value;
            }
        }

        public int AccountNo
        {
            get { return this.accountNo; }
            set
            {
                // account Number should be a positive integer value
                int number;
                if (Int32.TryParse(value.ToString(), out number) && number > 0)
                {
                    this.accountNo = value;
                }     
            }
        }

        public char CustomerType
        {
            get { return this.customerType; }
            set
            {
                if (Char.IsLetter(value))
                    this.customerType = value;
            }
        }

        public decimal ChargeAmount
        {
            get { return this.chargeAmount; }
            set
            {
                decimal number = 0;
                if (Decimal.TryParse(value.ToString(), out number) && number > 0)
                    this.chargeAmount = number;
            }
        }

        // abstract function to calculate charge
        public abstract decimal CalculateCharge(decimal kwhPowerUsed, decimal kwhOffPeakPowerUsed = 0);

        // Override ToString function
        public override string ToString()
        {
            return "AccountNo: " + this.accountNo + ", Customer Name: " + this.customerName +
                    ", Customer Type: " + Utils.CustomerTypeNames[this.customerType] +
                    ", Charge Amount: " + this.chargeAmount;
        }

        // abstract function to return customer data via array list.
        public abstract List<string> ToArrayOfValues();
  
    }
}
 