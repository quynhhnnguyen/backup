﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerData.Tests
{
    /* These are customer data tests.
       Author: Quynh Nguyen (Queenie)
       Date: Dec - 23 - 2018
     */
    [TestClass()]
    public class CustomerTests
    {
        /* Calculate Charge Amount 
         *  - for Residential Customer  
         *  - with Power Used greater than -1 
         */
        [TestMethod()]
        public void CalculateChargeForResidentialSuccess()
        {
            //Arrange
            decimal kWhPowerUsed = 999;
            Customer customer = new ResidentialCustomer(1, "Anna");
            decimal expectedChargeAmount = 57.948m;
            decimal actualChargeAmount;
            //Act
            customer.CalculateCharge(kWhPowerUsed);
            actualChargeAmount = customer.ChargeAmount;

            //Assert
            Assert.AreEqual(actualChargeAmount, expectedChargeAmount);
        }

        /* Calculate Charge Amount 
         *  - for Residential Customer  
         *  - with Negative kWh Power Used
         */
        [TestMethod()]
        public void CalculateChargeForResidentialWithNegativeKWHPowerUsed()
        {
            //Arrange
            decimal kWhPowerUsed = -1;
            Customer customer = new ResidentialCustomer(1, "Anna");
            decimal expectedChargeAmount = 0;
            decimal actualChargeAmount;
            //Act
            customer.CalculateCharge(kWhPowerUsed);
            actualChargeAmount = customer.ChargeAmount;

            //Assert
            Assert.AreEqual(actualChargeAmount, expectedChargeAmount);
        }

        /* Calculate Charge Amount 
         *  - for Commercial Customer  
         *  - with Power Used under 1000kWh 
         */
        [TestMethod()]
        public void CalculateChargeForCommercialUnder1000()
        {
            //Arrange
            decimal kWhPowerUsed = 999;
            Customer customer = new CommercialCustomer(2, "Bob");
            decimal expectedChargeAmount = 60;
            decimal actualChargeAmount;
            //Act
            customer.CalculateCharge(kWhPowerUsed);
            actualChargeAmount = customer.ChargeAmount;

            //Assert
            Assert.AreEqual(actualChargeAmount, expectedChargeAmount);
        }

        /* Calculate Charge Amount 
         *  - for Commercial Customer  
         *  - with Power Used over 1000kWh 
         */
        [TestMethod()]
        public void CalculateChargeForCommercialOver1000()
        {
            //Arrange
            decimal kWhPowerUsed = 1001;
            Customer customer = new CommercialCustomer(2, "Bob");
            decimal expectedChargeAmount = 60.045m;
            decimal actualChargeAmount;
            //Act
            customer.CalculateCharge(kWhPowerUsed);
            actualChargeAmount = customer.ChargeAmount;

            //Assert
            Assert.AreEqual(actualChargeAmount, expectedChargeAmount);
        }

        /* Calculate Charge Amount 
         *  - for Commercial Customer  
         *  - with Negative kWh Power Used
         */
        [TestMethod()]
        public void CalculateChargeForCommercialWithNegativeKWHPowerUsed()
        {
            //Arrange
            decimal kWhPowerUsed = -1;
            Customer customer = new CommercialCustomer(2, "Bob");
            decimal expectedChargeAmount = 0;
            decimal actualChargeAmount;
            //Act
            customer.CalculateCharge(kWhPowerUsed);
            actualChargeAmount = customer.ChargeAmount;

            //Assert
            Assert.AreEqual(actualChargeAmount, expectedChargeAmount);
        }

        /* Calculate Charge Amount 
         *  - for Industrial Customer  
         *  - with Peak Power Used under 1000kWh 
         *    and Off-Peak Power Used under 1000kWh
         */
        [TestMethod()]
        public void CalculateChargeForIndustrialBothPeakAndOffPeakUnder1000()
        {
            //Arrange
            decimal kWhPeakPowerUsed = 0;
            decimal kWhOffPeakPowerUsed = 0;
            Customer customer = new IndustrialCustomer(3, "Catus");
            decimal expectedChargeAmount = 116;
            decimal actualChargeAmount;
            //Act
            customer.CalculateCharge(kWhPeakPowerUsed, kWhOffPeakPowerUsed);
            actualChargeAmount = customer.ChargeAmount;

            //Assert
            Assert.AreEqual(actualChargeAmount, expectedChargeAmount);
        }

        /* Calculate Charge Amount 
         *  - for Industrial Customer  
         *  - with Peak Power Used over 1000kWh 
         *    and Off-Peak Power Used over 1000kWh
         */
        [TestMethod()]
        public void CalculateChargeForIndustrialBothPeakAndOffPeakOver1000()
        {
            //Arrange
            decimal kWhPeakPowerUsed = 1001;
            decimal kWhOffPeakPowerUsed = 1001;
            Customer customer = new IndustrialCustomer(3, "Catus");
            decimal expectedChargeAmount = 116.093m;
            decimal actualChargeAmount;
            //Act
            customer.CalculateCharge(kWhPeakPowerUsed, kWhOffPeakPowerUsed);
            actualChargeAmount = customer.ChargeAmount;

            //Assert
            Assert.AreEqual(actualChargeAmount, expectedChargeAmount);
        }

        /* Calculate Charge Amount 
         *  - for Industrial Customer  
         *  - with Negative kWh Power Used
         */
        [TestMethod()]
        public void CalculateChargeForIndustrialWithNegativeKWHPowerUsed()
        {
            //Arrange
            decimal kWhPeakPowerUsed = -1;
            decimal kWhOffPeakPowerUsed = -1;
            Customer customer = new IndustrialCustomer(3, "Catus");
            decimal expectedChargeAmount = 0;
            decimal actualChargeAmount;
            //Act
            customer.CalculateCharge(kWhPeakPowerUsed, kWhOffPeakPowerUsed);
            actualChargeAmount = customer.ChargeAmount;

            //Assert
            Assert.AreEqual(actualChargeAmount, expectedChargeAmount);
        }
    }
}