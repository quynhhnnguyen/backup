﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExpressionAndStack
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEvaluate_Click(object sender, EventArgs e)
        {
            Stack<char> st = new Stack<char>();
            bool valid = true; // innocent until proven guilty
            string expr = txtExpression.Text; // get the expression
            char current; // current character
            char popped; // char popped from stack
            for(int i=0; i<expr.Length; i++) // for each character
            {
                current = expr[i];
                switch(current)
                {
                    case '(':
                    case '{':
                    case '[':
                        st.Push(current); // push into stack any opening bracket
                        break;
                    case ')':
                    case '}':
                    case ']':
                        if (st.Count == 0)
                        {
                            valid = false;
                            break;
                        }
                        popped = (char)st.Pop();
                        if ((current == ')' && popped != '(') ||
                           (current == ']' && popped != '[') ||
                           (current == '}' && popped != '{'))
                        {
                            valid = false; break;
                        }
                        break;

                }
                if (!valid) break; // quit the loop if not valid
            } // end loop
            // test if remaining stack empty
            if (st.Count > 0) { valid = false; }
            if (valid)
            {
                lblMessage.ForeColor = Color.Green;
                lblMessage.Text = "It's valid";
            }
            else
            {
                lblMessage.ForeColor = Color.Red;
                lblMessage.Text = "It's in-valid";
            }
        }
    }
}
