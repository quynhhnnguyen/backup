﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PlayCards
{
    public partial class Form1 : Form
    {
        public enum Rank
        {
            Ace, Two, Three, Four, Five,
            Six, Seven, Eight, Nine, Ten, Jack, Queen, King
        }
        public enum Suit { Club, Diamond, Heart, Spade }

        Deck deck;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Initialize deck
            deck = new Deck();
            foreach (string rank in Enum.GetNames(typeof(Rank)))
            {
                foreach (string suit in Enum.GetNames(typeof(Suit)))
                {
                    Card card = new Card(rank, suit);
                    deck.Cards.Add(card);
                }
            }

            //display deck
            foreach(Card card in deck.Cards)
                lstBCards.Items.Add(card.ToString());
                
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Random gen = new Random();
            // MessageBox.Show();
            lstBCards.Items.Clear();

            //display cards to UI
            int count = 0;
            while(count<52)
            {
                if (lstBCards.Items.IndexOf(deck.Cards[gen.Next(52)].ToString()) == -1 )
                { // if the card doesn't exist, adding it to list of card
                    lstBCards.Items.Add(deck.Cards[gen.Next(52)].ToString());
                    count++;
                }

            }
        }
    }
}
