﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EntityFrameworkDemo
{
    public partial class frmMain : Form
    {
        //define object context
        MMABooksEntities entities = new MMABooksEntities();
        private object selectedCustInvoices;
        private Customer selectedCustomer;

        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            //populate the combo box
            var customerIDs = (from customer in entities.Customers
                               orderby customer.CustomerID
                               select customer.CustomerID).ToList();

            customerIDComboBox.DataSource = customerIDs;


        }

        private void customerIDComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // display customer's data
            int customerId = (int)customerIDComboBox.SelectedValue;
            selectedCustomer = (from customer in entities.Customers
                                where customer.CustomerID == customerId
                                select customer).Single(); //execute query & get only 1 row

            DisplayCustomer();

            //get the customer's invoices
            GetInvoices(customerId);
        }

        private void GetInvoices(int customerId)
        {
            selectedCustInvoices = (from invoice in entities.Invoices
                                    where invoice.CustomerID == customerId
                                    orderby invoice.InvoiceID
                                    select invoice).ToList(); // execute query & return list of objects
            invoiceDataGridView.DataSource = selectedCustInvoices;


            //invoiceDataGridView.DataSource = entities.Invoices.ToList();
        }

        private void DisplayCustomer()
        {
            
            nameTextBox.Text = selectedCustomer.Name;
            addressTextBox.Text = selectedCustomer.Address;
            cityTextBox.Text = selectedCustomer.City;
            stateTextBox.Text = selectedCustomer.State;
            zipCodeTextBox.Text = selectedCustomer.ZipCode;
        }
    }
}
