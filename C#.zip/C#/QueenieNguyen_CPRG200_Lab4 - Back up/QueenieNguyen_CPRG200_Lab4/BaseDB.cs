﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueenieNguyen_CPRG200_Lab4
{
    public static class BaseDB
    {
        //public static SqlConnection GetConnection()
        //{
        //    string connectionString = "Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=master;Integrated Security=True;";
        //}
    }
}
