﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HelloWorld
{
    /* This is our first code
     * Author: Quynh Nguyen (Queenie)
     * Date: Dec - 03 - 2018.     
     */
    public partial class frmLogin : Form
    {
        public frmLogin()
        {
            InitializeComponent();
        }

        private void lblCaption_Click(object sender, EventArgs e)
        {

        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            lblGreeting.Text = "Hello - " + txtUserName.Text;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            lblGreeting.Text = "";
            txtUserName.Text = "";

        }
    }
}
