﻿namespace Ex2_D3
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblWinner = new System.Windows.Forms.Label();
            this.txtWinner = new System.Windows.Forms.TextBox();
            this.btnFindWinner = new System.Windows.Forms.Button();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.llbTotal = new System.Windows.Forms.Label();
            this.dGVInfo = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lblTableCaption = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dGVInfo)).BeginInit();
            this.SuspendLayout();
            // 
            // lblWinner
            // 
            this.lblWinner.AutoSize = true;
            this.lblWinner.Location = new System.Drawing.Point(124, 115);
            this.lblWinner.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblWinner.Name = "lblWinner";
            this.lblWinner.Size = new System.Drawing.Size(70, 20);
            this.lblWinner.TabIndex = 0;
            this.lblWinner.Text = "Winner:";
            // 
            // txtWinner
            // 
            this.txtWinner.Location = new System.Drawing.Point(223, 109);
            this.txtWinner.Name = "txtWinner";
            this.txtWinner.Size = new System.Drawing.Size(111, 26);
            this.txtWinner.TabIndex = 1;
            // 
            // btnFindWinner
            // 
            this.btnFindWinner.Location = new System.Drawing.Point(219, 55);
            this.btnFindWinner.Name = "btnFindWinner";
            this.btnFindWinner.Size = new System.Drawing.Size(194, 25);
            this.btnFindWinner.TabIndex = 2;
            this.btnFindWinner.Text = "Find the Winner";
            this.btnFindWinner.UseVisualStyleBackColor = true;
            this.btnFindWinner.Click += new System.EventHandler(this.btnFindWinner_Click);
            // 
            // txtTotal
            // 
            this.txtTotal.Location = new System.Drawing.Point(223, 158);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(111, 26);
            this.txtTotal.TabIndex = 4;
            // 
            // llbTotal
            // 
            this.llbTotal.AutoSize = true;
            this.llbTotal.Location = new System.Drawing.Point(124, 164);
            this.llbTotal.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.llbTotal.Name = "llbTotal";
            this.llbTotal.Size = new System.Drawing.Size(54, 20);
            this.llbTotal.TabIndex = 3;
            this.llbTotal.Text = "Total:";
            // 
            // dGVInfo
            // 
            this.dGVInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGVInfo.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4,
            this.Column5});
            this.dGVInfo.Enabled = false;
            this.dGVInfo.Location = new System.Drawing.Point(113, 252);
            this.dGVInfo.Name = "dGVInfo";
            this.dGVInfo.RowHeadersVisible = false;
            this.dGVInfo.Size = new System.Drawing.Size(560, 150);
            this.dGVInfo.TabIndex = 5;
            this.dGVInfo.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Color/ Size";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "S";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "M";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "L";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "XL";
            this.Column5.Name = "Column5";
            // 
            // lblTableCaption
            // 
            this.lblTableCaption.AutoSize = true;
            this.lblTableCaption.Location = new System.Drawing.Point(124, 220);
            this.lblTableCaption.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTableCaption.Name = "lblTableCaption";
            this.lblTableCaption.Size = new System.Drawing.Size(215, 20);
            this.lblTableCaption.TabIndex = 6;
            this.lblTableCaption.Text = "T-Shirt Sales Information:";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(737, 414);
            this.Controls.Add(this.lblTableCaption);
            this.Controls.Add(this.dGVInfo);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.llbTotal);
            this.Controls.Add(this.btnFindWinner);
            this.Controls.Add(this.txtWinner);
            this.Controls.Add(this.lblWinner);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmMain";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dGVInfo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblWinner;
        private System.Windows.Forms.TextBox txtWinner;
        private System.Windows.Forms.Button btnFindWinner;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label llbTotal;
        private System.Windows.Forms.DataGridView dGVInfo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.Label lblTableCaption;
    }
}

