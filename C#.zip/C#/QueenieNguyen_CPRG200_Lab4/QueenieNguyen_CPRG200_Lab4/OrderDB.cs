﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QueenieNguyen_CPRG200_Lab4
{
    /* Business class for updating, selecting Order
     * Author: Queenie Nguyen
     * Created Date: Jan - 11 - 2019
     */

    public static class OrderDB
    {
        // northwind entities
        private static northwndEntities entities = new northwndEntities();

        // get Order Id List
        public static List<int> GetOrderIDs()
        {
            List<int> orderIds = (from order in entities.Orders
                                  select order.OrderID).ToList();

            return orderIds;
        }

        // get Order information by Id
        public static Order GetOrder(int orderId)
        {
            Order orderE = (from order in entities.Orders
                            where order.OrderID == orderId
                            select order).Single();

            return orderE;
        }

        // update shipped date for order via order id
        public static bool UpdateShippedDate(int orderId, DateTime shippedDate)
        {
            try
            {
                Order orderE = (from order in entities.Orders
                                where order.OrderID == orderId
                                select order).Single();
                orderE.ShippedDate = shippedDate;

                return entities.SaveChanges() == 1;
            }
            catch
            {
                return false;
            }
            
        }
    }
}
