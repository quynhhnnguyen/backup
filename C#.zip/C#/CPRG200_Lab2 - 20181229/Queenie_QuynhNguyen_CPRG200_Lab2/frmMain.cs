﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;
using CustomerData;

namespace Queenie_QuynhNguyen_CPRG200_Lab2
{
    /* This is application which allows Customer calculates the Power Charge Bill based on Customer Type
       Author: Quynh Nguyen (Queenie)
       Date: Dec - 05 - 2018
     */
    public partial class frmMain : Form
    {
        // class-level declarations
        // CONSTANT VARIABLES
        const decimal TAX_PCT = 0.05m; // tax percent
        private const string POWER_USED_LABEL = "Power Used (kWh):";
        private const string PEAK_HOUR_POWER_USED_LABEL = "Peak Hour Used (kWh):";
        private const string EMPTY_VALUE = "";
        private const string DOLLAR_FORMAT = "c";

        enum CustomerTypeEnum {Residential, Commercial, Industrial}; // Customer Types

        Customers custList = new Customers();
        decimal totalOfCharge = 0;
        string[] rCustomers, cCustomers, iCustomers;

        public frmMain()
        {
            InitializeComponent();
        }

        // Calculate the Power Charge Bill based on Customer Type
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal result = 0.0m; //output value

            int customerType = cbbCustomerType.SelectedIndex; // selected customer type

            try
            {
                // validate the input value
                if (Validator.IsProvided(txtPowerUsed, txtPowerUsed.Name) &&
                    Validator.IsNonNegativeNumber(txtPowerUsed, txtPowerUsed.Name))
                {

                    decimal kWhUsed = Convert.ToDecimal(txtPowerUsed.Text); // kWh power used or  kWh peak hour used

                    // calculate charged bill based on Customer Type
                    switch (customerType)
                    {
                        case (int)CustomerTypeEnum.Residential:
                            result = Utils.CalculateBillForResidential(kWhUsed);
                            break;
                        case (int)CustomerTypeEnum.Commercial:
                            result = Utils.CalculateBillForCommercial(kWhUsed);
                            break;
                        case (int)CustomerTypeEnum.Industrial:
                            // validate the input value
                            if (Validator.IsProvided(txtOffPeakHours, txtOffPeakHours.Name) &&
                                     Validator.IsNonNegativeNumber(txtOffPeakHours, txtOffPeakHours.Name))
                            {
                                // kWh off-peak hour used
                                decimal kWhOffPeakHours = Convert.ToDecimal(txtOffPeakHours.Text);
                                result = Utils.CalculateBillForIndustrial(kWhUsed, kWhOffPeakHours);                                
                            }

                            break;

                    }

                    DrawBillInformation(result, kWhUsed);
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" +
                                ex.GetType().ToString() + "\n", "Exception");
            }
           
        }

        private void DrawBillInformation(decimal result, decimal kWhUsed)
        {
            //set information for Bill
            if(cbbCustomerType.SelectedIndex == (int)CustomerTypeEnum.Industrial)
                txtOffPeakInfo.Text = txtOffPeakHours.Text;

            //set information for Bill
            txtEstimatedCharge.Text = result.ToString(DOLLAR_FORMAT);
            txtPowerUsedInfo.Text = kWhUsed.ToString();
            grpBInfo.Show();
        }        

        // Reset all information on Form
        private void btnReset_Click(object sender, EventArgs e)
        {
            txtAccountNo.Text = EMPTY_VALUE;
            txtCustomerName.Text = EMPTY_VALUE;
            txtAccountNo.Focus();
            lblPowerUsed.Text = POWER_USED_LABEL;
            lblPowerUsedInfo.Text = POWER_USED_LABEL;
            txtPowerUsed.Text = EMPTY_VALUE;
            txtEstimatedCharge.Text = EMPTY_VALUE;
            cbbCustomerType.SelectedIndex = (int)CustomerTypeEnum.Residential;
            grpBoxPeakHour.Visible = false;
            grpBInfo.Hide();
        }

        // Exit button is hit, close the form and exit the application
        private void btnExit_Click(object sender, EventArgs e)
        {
            Utils.WriteData(custList);
            this.Close();
        }

        // display peak/ off-peak hours input based on Customer Type
        private void cbbCustomerType_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtEstimatedCharge.Text = EMPTY_VALUE;
            txtPowerUsed.Text = EMPTY_VALUE;
            txtAccountNo.Text = EMPTY_VALUE;
            txtCustomerName.Text = EMPTY_VALUE;

            // peak hour power used & off-peak hour power used are displayed for Industrial Customer Only.
            if ((int)CustomerTypeEnum.Industrial == cbbCustomerType.SelectedIndex)
            {
                //input information Section
                grpBoxPeakHour.Visible = true;
                lblPowerUsed.Text = PEAK_HOUR_POWER_USED_LABEL;
                lblPowerUsedInfo.Text = PEAK_HOUR_POWER_USED_LABEL;

                //Bill information Section
                lblOffPeakInfo.Show();
                txtOffPeakInfo.Show();

            } else
            {
                //input information Section
                grpBoxPeakHour.Visible = false;
                lblPowerUsed.Text = POWER_USED_LABEL;
                lblPowerUsedInfo.Text = POWER_USED_LABEL;
                txtOffPeakHours.Text = EMPTY_VALUE;

                //Bill information Section
                lblOffPeakInfo.Hide();
                txtOffPeakInfo.Hide();
            }

            //Bill information Section
            grpBInfo.Hide();
        }

        // set default value for all components when Form is loaded
        private void frmMain_Load(object sender, EventArgs e)
        {
            txtPowerUsed.Focus();
            cbbCustomerType.SelectedIndex = (int)CustomerTypeEnum.Residential;
            grpBoxPeakHour.Hide();
            grpBInfo.Hide();
            custList = Utils.LoadCustomersFromFile();



            /*rCustomers = custList.ResidentialCustomers.getTotalNumbers(Utils.CustomerTypeEnum.Residential);
            totalOfCharge += Convert.ToDecimal(rCustomers[2]);
            DrawDataGridTables(rCustomers, custList.ResidentialCustomers.getCustomersInfo());

            cCustomers = custList.CommercialCustomers.getTotalNumbers();
            totalOfCharge += Convert.ToDecimal(cCustomers[2]);
            DrawDataGridTables(cCustomers, custList.CommercialCustomers.getCustomersInfo());

            iCustomers = custList.IndustrialCustomers.getTotalNumbers();
            totalOfCharge += Convert.ToDecimal(iCustomers[2]);
            DrawDataGridTables(iCustomers, custList.IndustrialCustomers.getCustomersInfo());*/

            rCustomers = custList.getTotalNumbers("R");
            totalOfCharge += Convert.ToDecimal(rCustomers[2]);
            DrawDataGridTables(rCustomers, custList.getCustomersInfo("R"));

            cCustomers = custList.getTotalNumbers("C");
            totalOfCharge += Convert.ToDecimal(cCustomers[2]);
            DrawDataGridTables(cCustomers, custList.getCustomersInfo("C"));

            iCustomers = custList.getTotalNumbers("I");
            totalOfCharge += Convert.ToDecimal(iCustomers[2]);
            DrawDataGridTables(iCustomers, custList.getCustomersInfo("I"));

            txtTotalOfAllCharge.Text = totalOfCharge.ToString("c");

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int customerType = cbbCustomerType.SelectedIndex; // selected customer type

            try
            {
                // validate the input value
                if (Validator.IsProvided(txtAccountNo, lblAccountNo.Text) &&
                    Validator.IsNonNegativeNumber(txtAccountNo, lblAccountNo.Text) &&
                    Validator.IsProvided(txtCustomerName, lblCustomerName.Text) &&
                    Validator.IsProvided(txtPowerUsed, lblPowerUsed.Text) &&
                    Validator.IsNonNegativeNumber(txtPowerUsed, lblPowerUsed.Text))
                {

                    decimal kWhUsed = Convert.ToDecimal(txtPowerUsed.Text); // kWh power used or  kWh peak hour used
                    Customer customer = null;
                    Int32 acctNo = Convert.ToInt32(txtAccountNo.Text);
                    string custName = txtCustomerName.Text;

                    // calculate charged bill based on Customer Type
                    switch (customerType)
                    {
                        case (int)CustomerTypeEnum.Residential:
                            customer = new ResidentialCustomer(acctNo, custName);
                            customer.CalculateCharge(Convert.ToDecimal(txtPowerUsed.Text));
                            custList.ResidentialCustomers.Add((ResidentialCustomer)customer);

                            rCustomers[1] = custList.ResidentialCustomers.Count.ToString();
                            rCustomers[2] = (Convert.ToDecimal(rCustomers[2]) + customer.ChargeAmount).ToString();
                            dtGVTotalInfo.Rows.RemoveAt(0);
                            dtGVTotalInfo.Rows.Insert(0, rCustomers);
                            break;
                        case (int)CustomerTypeEnum.Commercial:
                            customer = new CommercialCustomer(acctNo, custName);
                            customer.CalculateCharge(Convert.ToDecimal(txtPowerUsed.Text));
                            custList.CommercialCustomers.Add((CommercialCustomer)customer);

                            cCustomers[1] = custList.CommercialCustomers.Count.ToString();
                            cCustomers[2] = (Convert.ToDecimal(rCustomers[2]) + customer.ChargeAmount).ToString();
                            dtGVTotalInfo.Rows.RemoveAt(1);
                            dtGVTotalInfo.Rows.Insert(1, cCustomers);
                            break;
                        case (int)CustomerTypeEnum.Industrial:
                            // validate the input value
                            if (Validator.IsProvided(txtOffPeakHours, lblOffPeakHours.Name) &&
                                     Validator.IsNonNegativeNumber(txtOffPeakHours, lblOffPeakHours.Name))
                            {
                                customer = new IndustrialCustomer(acctNo, custName);
                                customer.CalculateCharge(Convert.ToDecimal(txtPowerUsed.Text),
                                    Convert.ToDecimal(txtOffPeakHours.Text));
                                custList.IndustrialCustomers.Add((IndustrialCustomer)customer);

                                iCustomers[1] = custList.IndustrialCustomers.Count.ToString();
                                iCustomers[2] = (Convert.ToDecimal(rCustomers[2]) + customer.ChargeAmount).ToString();
                                dtGVTotalInfo.Rows.RemoveAt(2);
                                dtGVTotalInfo.Rows.Insert(2, iCustomers);

                            }
                            break;

                    }
                    if(customer != null)
                    {                        
                        DrawDataGridTables(customer);
                        totalOfCharge += customer.ChargeAmount;
                        txtTotalOfAllCharge.Text = totalOfCharge.ToString("c");
                    }
                        
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n" +
                                ex.GetType().ToString() + "\n", "Exception");
            }
        }

        private void DrawDataGridTables(string[] totalInfo, ArrayList custInfo)
        {
            //draw customer information table
            foreach(string[] cust in custInfo)
                dataGridCustInfo.Rows.Add(cust);

            //draw total information table
            dtGVTotalInfo.Rows.Add(totalInfo);
        }

        private void DrawDataGridTables(Customer cust)
        {
            //draw customer information table
            dataGridCustInfo.Rows.Add(cust.ToArrayOfValues().ToArray());
        }


        // save data as the form closes
        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            Utils.WriteData(custList);
        }

    }
}
