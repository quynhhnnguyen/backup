﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PlayCards
{
    class Deck
    {
        private List<Card> cards = new List<Card>();

        public Deck()
        {
            //this.cards = cards;
        }

        public Deck(List<Card> cards)
        {
            this.cards = cards;
        }

        public List<Card> Cards
        {
            get { return cards; }
            set { cards = value; }
        }
    }
}
